//
//  CoreComponents.swift
//  UNORMA
//
//  DESIGN SYSTEM — the reusable building blocks every screen is assembled from.
//

import SwiftUI

// MARK: - Background

/// The app's page background: a tinted wash with soft ambient orbs and a
/// faint diagonal sheen, so no screen ever reads as a flat empty rectangle.
struct AppBackground: View {

    @Environment(\.palette) private var palette

    var body: some View {
        ZStack {
            palette.frame

            Circle()
                .fill(palette.accent.opacity(0.16))
                .frame(width: 320, height: 320)
                .blur(radius: 70)
                .offset(x: -140, y: -250)

            Circle()
                .fill(palette.accentDeep.opacity(0.14))
                .frame(width: 360, height: 360)
                .blur(radius: 80)
                .offset(x: 160, y: 300)

            LinearGradient(
                colors: [palette.accent.opacity(0.06), .clear],
                startPoint: .topTrailing,
                endPoint: .center
            )
        }
        .ignoresSafeArea()
    }
}

// MARK: - Headers

/// The deep blue gradient band used at the top of the auth flow and detail screens.
struct GradientHeader<Content: View>: View {

    @Environment(\.palette) private var palette

    /// Optional floor for the band's height. The content always drives the
    /// real height — the decorative orbs live in a background layer so they
    /// can never inflate it (which previously pushed the content out of the
    /// clipped bounds and made the back button unreachable).
    var minHeight: CGFloat?
    @ViewBuilder var content: Content

    var body: some View {
        content
            .frame(maxWidth: .infinity)
            .frame(minHeight: minHeight)
            .background(alignment: .top) { decorations }
            .clipShape(
                UnevenRoundedRectangle(
                    bottomLeadingRadius: 26,
                    bottomTrailingRadius: 26,
                    style: .continuous
                )
            )
    }

    /// Purely visual — sized to the header, never part of its layout.
    private var decorations: some View {
        ZStack(alignment: .top) {
            palette.headerGradient

            Circle()
                .fill(.white.opacity(0.05))
                .frame(width: 180, height: 180)
                .offset(x: 110, y: -70)

            Circle()
                .stroke(.white.opacity(0.07), lineWidth: 26)
                .frame(width: 260, height: 260)
                .offset(x: -130, y: 40)
        }
    }
}

/// Compact navigation bar for pushed screens: back chevron, context label, wordmark.
struct DetailTopBar: View {

    @Environment(\.palette) private var palette

    let contextLabel: String
    let subtitle: String?
    var onBack: () -> Void

    var body: some View {
        GradientHeader(minHeight: subtitle == nil ? 54 : 64) {
            VStack(spacing: 2) {
                HStack {
                    Button(action: onBack) {
                        HStack(spacing: 3) {
                            Image(systemName: "chevron.left")
                                .font(.system(size: 14, weight: .bold))
                            Text(contextLabel)
                                .font(UNFont.captionMedium)
                        }
                        .foregroundStyle(.white.opacity(0.85))
                    }
                    .buttonStyle(.plain)

                    Spacer()

                    Text("UNORMA")
                        .font(UNFont.wordmarkSmall)
                        .tracking(2)
                        .foregroundStyle(.white)

                    Spacer()

                    // Balances the leading button so the wordmark stays centred.
                    Color.clear.frame(width: 62, height: 1)
                }

                if let subtitle {
                    Text(subtitle)
                        .font(.system(size: 10, weight: .semibold))
                        .tracking(1.4)
                        .foregroundStyle(.white.opacity(0.6))
                }
            }
            .padding(.horizontal, UNMetrics.screenPadding)
            .padding(.top, 10)
            .padding(.bottom, 14)
        }
    }
}

/// Title bar for root tab screens — wordmark over the screen name.
struct SectionTopBar: View {

    let title: String

    var body: some View {
        GradientHeader(minHeight: 64) {
            VStack(spacing: 2) {
                Text("UNORMA")
                    .font(UNFont.wordmarkSmall)
                    .tracking(2)
                    .foregroundStyle(.white)

                Text(title.uppercased())
                    .font(.system(size: 10, weight: .semibold))
                    .tracking(1.6)
                    .foregroundStyle(.white.opacity(0.6))
            }
            .padding(.top, 10)
            .padding(.bottom, 14)
        }
    }
}

/// The greeting band on the Explore / My Org dashboards.
struct WelcomeHeader: View {

    let name: String

    var body: some View {
        GradientHeader(minHeight: 76) {
            HStack(alignment: .center) {
                VStack(alignment: .leading, spacing: 1) {
                    Text("Welcome Back,")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundStyle(.white.opacity(0.6))
                    Text(name)
                        .font(.system(size: 21, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                        .lineLimit(1)
                }

                Spacer()

                Text("UNORMA")
                    .font(UNFont.wordmarkSmall)
                    .tracking(2)
                    .foregroundStyle(.white)

                UnormaLogoTile(size: 30, tileOpacity: 0.18)
                    .padding(.leading, 8)
            }
            .padding(.horizontal, UNMetrics.screenPadding)
            .padding(.top, 12)
            .padding(.bottom, 16)
        }
    }
}

// MARK: - Containers

/// The standard white (or midnight) card surface.
struct UNCard<Content: View>: View {

    @Environment(\.palette) private var palette

    var padding: CGFloat = 16
    @ViewBuilder var content: Content

    var body: some View {
        content
            .padding(padding)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(palette.card)
            .clipShape(RoundedRectangle(cornerRadius: UNMetrics.cardRadius, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: UNMetrics.cardRadius, style: .continuous)
                    .strokeBorder(palette.cardBorder, lineWidth: 1)
            )
            .shadow(color: palette.shadow, radius: 12, x: 0, y: 3)
    }
}

/// "Organizations", "Quick Actions" — the small bold label above a group.
struct SectionHeader: View {

    @Environment(\.palette) private var palette

    let title: String
    var trailing: String?

    var body: some View {
        HStack {
            Text(title)
                .font(UNFont.sectionTitle)
                .foregroundStyle(palette.ink)
            Spacer()
            if let trailing {
                Text(trailing)
                    .font(UNFont.captionMedium)
                    .foregroundStyle(palette.accent)
            }
        }
    }
}

// MARK: - Buttons

/// Full-width gradient call to action.
struct PrimaryButton: View {

    @Environment(\.palette) private var palette
    @Environment(\.isEnabled) private var isEnabled

    let title: String
    var systemImage: String?
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 8) {
                if let systemImage {
                    Image(systemName: systemImage)
                        .font(.system(size: 15, weight: .bold))
                }
                Text(title)
                    .font(.system(size: 16, weight: .bold, design: .rounded))
            }
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity)
            .frame(height: 50)
            .background(palette.primaryButtonGradient)
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            .shadow(color: palette.accentDeep.opacity(0.28), radius: 10, x: 0, y: 5)
            .opacity(isEnabled ? 1 : 0.45)
        }
        .buttonStyle(PressableStyle())
    }
}

/// Outlined secondary action.
struct SecondaryButton: View {

    @Environment(\.palette) private var palette

    let title: String
    var tint: Color?
    var height: CGFloat = 42
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 15, weight: .semibold, design: .rounded))
                .foregroundStyle(tint ?? palette.accent)
                .frame(maxWidth: .infinity)
                .frame(height: height)
                .background((tint ?? palette.accent).opacity(0.10))
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                        .strokeBorder((tint ?? palette.accent).opacity(0.30), lineWidth: 1)
                )
        }
        .buttonStyle(PressableStyle())
    }
}

/// Gives every tappable surface the same subtle press response.
struct PressableStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.97 : 1)
            .opacity(configuration.isPressed ? 0.85 : 1)
            .animation(.easeOut(duration: 0.12), value: configuration.isPressed)
    }
}

// MARK: - Segmented control

/// The two-up pill toggle: Sign In / Register, All Events / My Events.
struct SegmentedToggle: View {

    @Environment(\.palette) private var palette

    let options: [String]
    @Binding var selection: Int
    var onLightBackground: Bool = false

    private var trackColor: Color {
        onLightBackground ? palette.accent.opacity(0.10) : .white.opacity(0.14)
    }

    private var inactiveText: Color {
        onLightBackground ? palette.inkSecondary : .white.opacity(0.7)
    }

    var body: some View {
        GeometryReader { proxy in
            let segmentWidth = proxy.size.width / CGFloat(max(options.count, 1))

            ZStack(alignment: .leading) {
                Capsule().fill(trackColor)

                Capsule()
                    .fill(palette.card)
                    .padding(4)
                    .frame(width: segmentWidth)
                    .offset(x: segmentWidth * CGFloat(selection))
                    .shadow(color: palette.shadow, radius: 6, x: 0, y: 2)

                HStack(spacing: 0) {
                    ForEach(Array(options.enumerated()), id: \.offset) { index, label in
                        Button {
                            withAnimation(.spring(response: 0.34, dampingFraction: 0.82)) {
                                selection = index
                            }
                        } label: {
                            Text(label)
                                .font(.system(size: 14, weight: .bold, design: .rounded))
                                .foregroundStyle(selection == index ? palette.ink : inactiveText)
                                .frame(width: segmentWidth, height: proxy.size.height)
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
        .frame(height: 44)
    }
}

// MARK: - Chips

/// Horizontal scrolling filter chips ("All", "Governance", "Academic"...).
struct FilterChipRow: View {

    @Environment(\.palette) private var palette

    let titles: [String]
    @Binding var selection: Int

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(Array(titles.enumerated()), id: \.offset) { index, title in
                    let isSelected = index == selection
                    Button {
                        withAnimation(.easeOut(duration: 0.2)) { selection = index }
                    } label: {
                        Text(title)
                            .font(.system(size: 13, weight: .semibold))
                            .foregroundStyle(isSelected ? .white : palette.inkSecondary)
                            .padding(.horizontal, 15)
                            .padding(.vertical, 9)
                            .background(isSelected ? palette.accent : palette.card)
                            .clipShape(Capsule())
                            .overlay(
                                Capsule().strokeBorder(
                                    isSelected ? .clear : palette.cardBorder,
                                    lineWidth: 1
                                )
                            )
                    }
                    .buttonStyle(PressableStyle())
                }
            }
            .padding(.horizontal, UNMetrics.screenPadding)
            .padding(.vertical, 2)
        }
    }
}

/// Small status pill: Pending / Approved / Upcoming / Academic.
struct StatusTag: View {

    let text: String
    let foreground: Color
    let background: Color

    var body: some View {
        Text(text)
            .font(UNFont.tag)
            .foregroundStyle(foreground)
            .padding(.horizontal, 10)
            .padding(.vertical, 5)
            .background(background)
            .clipShape(Capsule())
    }
}

extension StatusTag {
    static func forApplication(_ status: ApplicationStatus, palette: Palette) -> StatusTag {
        switch status {
        case .pending:
            return StatusTag(text: status.rawValue, foreground: palette.warning, background: palette.warningSoft)
        case .approved:
            return StatusTag(text: status.rawValue, foreground: palette.success, background: palette.successSoft)
        case .rejected:
            return StatusTag(text: status.rawValue, foreground: palette.danger, background: palette.danger.opacity(0.14))
        }
    }

    static func forEvent(_ status: EventStatus, palette: Palette) -> StatusTag {
        switch status {
        case .upcoming:
            return StatusTag(text: status.rawValue, foreground: palette.accent, background: palette.accentSoft)
        case .ongoing:
            return StatusTag(text: status.rawValue, foreground: palette.success, background: palette.successSoft)
        case .completed:
            return StatusTag(text: "Past", foreground: palette.inkSecondary, background: palette.inkSecondary.opacity(0.14))
        }
    }
}

// MARK: - Search

struct SearchField: View {

    @Environment(\.palette) private var palette

    let placeholder: String
    @Binding var text: String

    var body: some View {
        HStack(spacing: 9) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(palette.inkSecondary.opacity(0.8))

            TextField(placeholder, text: $text)
                .font(UNFont.body)
                .foregroundStyle(palette.ink)
                .autocorrectionDisabled()
                .textInputAutocapitalization(.never)

            if !text.isEmpty {
                Button {
                    text = ""
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 14))
                        .foregroundStyle(palette.inkSecondary.opacity(0.6))
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 14)
        .frame(height: 46)
        .background(palette.card)
        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .strokeBorder(palette.cardBorder, lineWidth: 1)
        )
        .shadow(color: palette.shadow, radius: 8, x: 0, y: 2)
    }
}

// MARK: - Small pieces

/// Circular monogram avatar used for people throughout the app.
struct AvatarCircle: View {

    @Environment(\.palette) private var palette

    let initials: String
    var diameter: CGFloat = 38

    var body: some View {
        Circle()
            .fill(palette.accentSoft)
            .frame(width: diameter, height: diameter)
            .overlay(
                Text(initials)
                    .font(.system(size: diameter * 0.38, weight: .bold, design: .rounded))
                    .foregroundStyle(palette.accent)
            )
    }
}

/// Rounded emoji badge used for organizations and events.
struct EmojiBadge: View {

    @Environment(\.palette) private var palette

    let emoji: String
    var side: CGFloat = 46

    var body: some View {
        RoundedRectangle(cornerRadius: side * 0.30, style: .continuous)
            .fill(palette.accentSoft)
            .frame(width: side, height: side)
            .overlay(Text(emoji).font(.system(size: side * 0.48)))
    }
}

/// A big number over a small caption — used on dashboards.
struct StatTile: View {

    @Environment(\.palette) private var palette

    let value: String
    let caption: String

    var body: some View {
        VStack(spacing: 3) {
            Text(value)
                .font(UNFont.statNumber)
                .foregroundStyle(palette.accent)
            Text(caption)
                .font(.system(size: 11, weight: .medium))
                .foregroundStyle(palette.inkSecondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
    }
}

/// Label on the left, value on the right — the Account / Overview rows.
struct InfoRow: View {

    @Environment(\.palette) private var palette

    let label: String
    let value: String
    var isLast: Bool = false

    var body: some View {
        VStack(spacing: 0) {
            HStack(alignment: .firstTextBaseline) {
                Text(label)
                    .font(UNFont.bodyMedium)
                    .foregroundStyle(palette.ink)
                Spacer(minLength: 12)
                Text(value)
                    .font(UNFont.body)
                    .foregroundStyle(palette.inkSecondary)
                    .multilineTextAlignment(.trailing)
            }
            .padding(.vertical, 13)

            if !isLast {
                Rectangle()
                    .fill(palette.cardBorder)
                    .frame(height: 1)
            }
        }
    }
}

/// The illustrated "nothing here yet" state.
struct EmptyState: View {

    @Environment(\.palette) private var palette

    let emoji: String
    let title: String
    let message: String

    var body: some View {
        VStack(spacing: 10) {
            ZStack {
                Circle()
                    .fill(palette.accentSoft)
                    .frame(width: 86, height: 86)
                Text(emoji).font(.system(size: 36))
            }
            .padding(.bottom, 4)

            Text(title)
                .font(UNFont.sectionTitle)
                .foregroundStyle(palette.ink)

            Text(message)
                .font(UNFont.caption)
                .foregroundStyle(palette.inkSecondary)
                .multilineTextAlignment(.center)
                .frame(maxWidth: 250)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 56)
    }
}

/// Two-up shortcut tiles under "Quick Actions".
struct QuickActionTile: View {

    @Environment(\.palette) private var palette

    let systemImage: String
    let title: String
    let subtitle: String
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 8) {
                ZStack {
                    RoundedRectangle(cornerRadius: 11, style: .continuous)
                        .fill(palette.accentSoft)
                        .frame(width: 34, height: 34)
                    Image(systemName: systemImage)
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(palette.accent)
                }

                Spacer(minLength: 6)

                Text(title)
                    .font(UNFont.cardTitle)
                    .foregroundStyle(palette.ink)
                    .lineLimit(1)

                Text(subtitle)
                    .font(UNFont.caption)
                    .foregroundStyle(palette.inkSecondary)
                    .lineLimit(1)
            }
            .padding(14)
            .frame(maxWidth: .infinity, minHeight: 118, alignment: .leading)
            .background(palette.card)
            .clipShape(RoundedRectangle(cornerRadius: UNMetrics.cardRadius, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: UNMetrics.cardRadius, style: .continuous)
                    .strokeBorder(palette.cardBorder, lineWidth: 1)
            )
            .shadow(color: palette.shadow, radius: 10, x: 0, y: 3)
        }
        .buttonStyle(PressableStyle())
    }
}

// MARK: - Swipe back

/// Restores the left-edge swipe-to-go-back gesture on screens that hide the
/// system navigation bar in favour of `DetailTopBar`. Attached as a
/// simultaneous gesture so it never interferes with vertical scrolling.
struct EdgeSwipeBack: ViewModifier {

    let onBack: () -> Void

    func body(content: Content) -> some View {
        content.simultaneousGesture(
            DragGesture(minimumDistance: 20)
                .onEnded { value in
                    guard value.startLocation.x < 28 else { return }
                    guard value.translation.width > 60 else { return }
                    guard abs(value.translation.height) < 70 else { return }
                    onBack()
                }
        )
    }
}

extension View {
    /// Adds edge-swipe dismissal to a detail screen.
    func edgeSwipeBack(perform onBack: @escaping () -> Void) -> some View {
        modifier(EdgeSwipeBack(onBack: onBack))
    }
}
