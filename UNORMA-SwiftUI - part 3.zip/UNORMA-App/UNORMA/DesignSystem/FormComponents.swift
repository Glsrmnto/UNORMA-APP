//
//  FormComponents.swift
//  UNORMA
//
//  DESIGN SYSTEM — labelled inputs, pickers and banners shared by the auth forms.
//

import SwiftUI
import UIKit

/// The small uppercase label that sits above every field.
struct FieldLabel: View {

    @Environment(\.palette) private var palette

    let text: String
    var uppercased: Bool = false

    @ViewBuilder
    var body: some View {
        if !text.isEmpty {
            Text(uppercased ? text.uppercased() : text)
                .font(UNFont.fieldLabel)
                .tracking(uppercased ? 0.8 : 0.2)
                .foregroundStyle(palette.accent)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
    }
}

/// Shared chrome so text, secure and menu fields all look identical.
private struct FieldChrome: ViewModifier {

    @Environment(\.palette) private var palette

    func body(content: Content) -> some View {
        content
            .padding(.horizontal, 14)
            .frame(height: 48)
            .background(palette.input)
            .clipShape(RoundedRectangle(cornerRadius: UNMetrics.controlRadius, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: UNMetrics.controlRadius, style: .continuous)
                    .strokeBorder(palette.inputBorder, lineWidth: 1)
            )
    }
}

private extension View {
    func fieldChrome() -> some View { modifier(FieldChrome()) }
}

/// A labelled plain text field.
struct UNTextField: View {

    @Environment(\.palette) private var palette

    let label: String
    let placeholder: String
    @Binding var text: String
    var keyboard: UIKeyboardType = .default
    var capitalization: TextInputAutocapitalization = .sentences
    var uppercasedLabel: Bool = false

    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            FieldLabel(text: label, uppercased: uppercasedLabel)

            TextField(placeholder, text: $text)
                .font(UNFont.body)
                .foregroundStyle(palette.ink)
                .keyboardType(keyboard)
                .textInputAutocapitalization(capitalization)
                .autocorrectionDisabled()
                .fieldChrome()
        }
    }
}

/// A labelled password field with a reveal toggle.
struct UNSecureField: View {

    @Environment(\.palette) private var palette

    let label: String
    let placeholder: String
    @Binding var text: String

    @State private var isRevealed = false

    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            FieldLabel(text: label)

            HStack(spacing: 8) {
                Group {
                    if isRevealed {
                        TextField(placeholder, text: $text)
                    } else {
                        SecureField(placeholder, text: $text)
                    }
                }
                .font(UNFont.body)
                .foregroundStyle(palette.ink)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()

                Button {
                    isRevealed.toggle()
                } label: {
                    Image(systemName: isRevealed ? "eye.slash" : "eye")
                        .font(.system(size: 15))
                        .foregroundStyle(palette.accent.opacity(0.75))
                }
                .buttonStyle(.plain)
            }
            .fieldChrome()
        }
    }
}

/// A labelled dropdown backed by a `Menu`.
struct UNMenuField: View {

    @Environment(\.palette) private var palette

    let label: String
    let placeholder: String
    let options: [String]
    @Binding var selection: String?

    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            FieldLabel(text: label)

            Menu {
                ForEach(options, id: \.self) { option in
                    Button(option) { selection = option }
                }
            } label: {
                HStack {
                    Text(selection ?? placeholder)
                        .font(UNFont.body)
                        .foregroundStyle(selection == nil ? palette.inkSecondary.opacity(0.75) : palette.ink)
                        .lineLimit(1)
                    Spacer()
                    Image(systemName: "chevron.up.chevron.down")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundStyle(palette.accent.opacity(0.8))
                }
                .fieldChrome()
            }
        }
    }
}

/// The "I am joining as a…" role picker — two large selectable cards.
struct RoleSelectionCard: View {

    @Environment(\.palette) private var palette

    let role: UserRole
    let isSelected: Bool
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 6) {
                Image(systemName: role.glyph)
                    .font(.system(size: 19, weight: .semibold))
                    .foregroundStyle(palette.accent)

                Text(role.title)
                    .font(UNFont.cardTitle)
                    .foregroundStyle(palette.ink)

                Text(role.subtitle)
                    .font(.system(size: 11))
                    .foregroundStyle(palette.inkSecondary)
                    .multilineTextAlignment(.leading)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding(13)
            .frame(maxWidth: .infinity, minHeight: 104, alignment: .topLeading)
            .background(isSelected ? palette.accentSoft : palette.input)
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .strokeBorder(
                        isSelected ? palette.accentDeep : palette.inputBorder,
                        lineWidth: isSelected ? 2 : 1
                    )
            )
        }
        .buttonStyle(PressableStyle())
        .animation(.easeOut(duration: 0.18), value: isSelected)
    }
}

/// A wrapping grid of single-choice pills — used for Year Level.
struct ChoiceGrid: View {

    @Environment(\.palette) private var palette

    let label: String
    let options: [String]
    @Binding var selection: String?
    var columns: Int = 3

    private var gridColumns: [GridItem] {
        Array(repeating: GridItem(.flexible(), spacing: 8), count: columns)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            FieldLabel(text: label)

            LazyVGrid(columns: gridColumns, spacing: 8) {
                ForEach(options, id: \.self) { option in
                    let isSelected = selection == option
                    Button {
                        withAnimation(.easeOut(duration: 0.16)) { selection = option }
                    } label: {
                        Text(option)
                            .font(.system(size: 13, weight: .semibold))
                            .foregroundStyle(isSelected ? .white : palette.inkSecondary)
                            .frame(maxWidth: .infinity)
                            .frame(height: 40)
                            .background(isSelected ? palette.accent : palette.input)
                            .clipShape(RoundedRectangle(cornerRadius: 11, style: .continuous))
                            .overlay(
                                RoundedRectangle(cornerRadius: 11, style: .continuous)
                                    .strokeBorder(isSelected ? .clear : palette.inputBorder, lineWidth: 1)
                            )
                    }
                    .buttonStyle(PressableStyle())
                }
            }
        }
    }
}

/// Inline validation message shown above the submit button.
struct ErrorBanner: View {

    @Environment(\.palette) private var palette

    let message: String

    var body: some View {
        HStack(alignment: .top, spacing: 8) {
            Image(systemName: "exclamationmark.triangle.fill")
                .font(.system(size: 13))
            Text(message)
                .font(UNFont.caption)
                .fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 0)
        }
        .foregroundStyle(palette.danger)
        .padding(11)
        .background(palette.danger.opacity(0.10))
        .clipShape(RoundedRectangle(cornerRadius: 11, style: .continuous))
    }
}

/// Soft amber advisory box, e.g. the Org Head scope notice.
struct NoticeBanner: View {

    @Environment(\.palette) private var palette

    let message: String

    var body: some View {
        Text(message)
            .font(.system(size: 12, weight: .medium))
            .foregroundStyle(palette.warning)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(11)
            .background(palette.warningSoft)
            .clipShape(RoundedRectangle(cornerRadius: 11, style: .continuous))
    }
}
