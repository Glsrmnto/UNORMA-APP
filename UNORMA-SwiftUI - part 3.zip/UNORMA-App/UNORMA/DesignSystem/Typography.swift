//
//  Typography.swift
//  UNORMA
//
//  DESIGN SYSTEM — one place for every font size, radius and spacing value.
//

import SwiftUI

enum UNFont {
    static let wordmark = Font.system(size: 30, weight: .black, design: .rounded)
    static let wordmarkSmall = Font.system(size: 17, weight: .heavy, design: .rounded)
    static let screenTitle = Font.system(size: 22, weight: .bold, design: .rounded)
    static let sectionTitle = Font.system(size: 17, weight: .bold, design: .rounded)
    static let cardTitle = Font.system(size: 16, weight: .semibold, design: .rounded)
    static let body = Font.system(size: 15, weight: .regular)
    static let bodyMedium = Font.system(size: 15, weight: .medium)
    static let caption = Font.system(size: 13, weight: .regular)
    static let captionMedium = Font.system(size: 13, weight: .medium)
    static let fieldLabel = Font.system(size: 12, weight: .bold)
    static let tag = Font.system(size: 11, weight: .bold)
    static let statNumber = Font.system(size: 26, weight: .black, design: .rounded)
    static let tabLabel = Font.system(size: 10, weight: .semibold)
}

enum UNMetrics {
    static let screenPadding: CGFloat = 18
    static let cardRadius: CGFloat = 18
    static let controlRadius: CGFloat = 12
    static let pillRadius: CGFloat = 999
    static let sectionSpacing: CGFloat = 22
    static let itemSpacing: CGFloat = 12
    static let tabBarHeight: CGFloat = 58
}

extension View {
    /// Standard horizontal inset used by every scrolling screen.
    func screenInset() -> some View {
        padding(.horizontal, UNMetrics.screenPadding)
    }
}
