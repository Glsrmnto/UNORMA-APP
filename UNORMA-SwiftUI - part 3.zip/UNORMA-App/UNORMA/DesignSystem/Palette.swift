//
//  Palette.swift
//  UNORMA
//
//  DESIGN SYSTEM — the colour tokens lifted from the UNORMA design file.
//  Two palettes ship: the default light blue and the midnight blue dark mode.
//

import SwiftUI

struct Palette {

    // Surfaces
    let frame: Color
    let card: Color
    let cardBorder: Color
    let input: Color
    let inputBorder: Color
    let tabBar: Color
    let tabBarBorder: Color

    // Text
    let ink: Color
    let inkSecondary: Color
    let inkOnAccent: Color

    // Brand
    let accent: Color
    let accentDeep: Color
    let accentSoft: Color
    let headerTop: Color
    let headerBottom: Color

    // Semantics
    let success: Color
    let successSoft: Color
    let warning: Color
    let warningSoft: Color
    let danger: Color

    // Elevation
    let shadow: Color

    /// Gradient used by every navigation header and the splash screen.
    var headerGradient: LinearGradient {
        LinearGradient(
            colors: [headerTop, headerBottom],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }

    /// Gradient used by primary call-to-action buttons.
    var primaryButtonGradient: LinearGradient {
        LinearGradient(
            colors: [accentDeep, headerBottom],
            startPoint: .leading,
            endPoint: .trailing
        )
    }

    // MARK: - Light blue (default)

    static let lightBlue = Palette(
        frame: Color(hex: 0xF4F6FF),
        card: Color(hex: 0xFFFFFF),
        cardBorder: Color(hex: 0x090D3C).opacity(0.08),
        input: Color(hex: 0xF4F6FF),
        inputBorder: Color(hex: 0x090D3C).opacity(0.12),
        tabBar: Color(hex: 0xF4F6FF).opacity(0.96),
        tabBarBorder: Color(hex: 0x090D3C).opacity(0.08),
        ink: Color(hex: 0x090D3C),
        inkSecondary: Color(hex: 0x5970E8),
        inkOnAccent: .white,
        accent: Color(hex: 0x5970E8),
        accentDeep: Color(hex: 0x0C1F6E),
        accentSoft: Color(hex: 0x5970E8).opacity(0.12),
        headerTop: Color(hex: 0x0C1F6E),
        headerBottom: Color(hex: 0x1A3090),
        success: Color(hex: 0x1F9D55),
        successSoft: Color(hex: 0xC9F2DC),
        warning: Color(hex: 0x9A6B00),
        warningSoft: Color(hex: 0xFCEFC7),
        danger: Color(hex: 0xD32F2F),
        shadow: Color(hex: 0x090D3C).opacity(0.10)
    )

    // MARK: - Midnight blue (dark mode)

    static let midnight = Palette(
        frame: Color(hex: 0x080C3A),
        card: Color(hex: 0x182190),
        cardBorder: Color(hex: 0x5970E8).opacity(0.35),
        input: Color(hex: 0x0F1760),
        inputBorder: Color(hex: 0x5970E8).opacity(0.30),
        tabBar: Color(hex: 0x080C3A).opacity(0.96),
        tabBarBorder: Color(hex: 0x5970E8).opacity(0.22),
        ink: Color(hex: 0xFFFFFF),
        inkSecondary: Color(hex: 0x8E9EF4),
        inkOnAccent: .white,
        accent: Color(hex: 0x5970E8),
        accentDeep: Color(hex: 0x8E9EF4),
        accentSoft: Color(hex: 0x5970E8).opacity(0.22),
        headerTop: Color(hex: 0x090D3C),
        headerBottom: Color(hex: 0x0C1F6E),
        success: Color(hex: 0x6EE7A8),
        successSoft: Color(hex: 0x0E4A31),
        warning: Color(hex: 0xF5C765),
        warningSoft: Color(hex: 0x4A3A0E),
        danger: Color(hex: 0xEF5350),
        shadow: Color.black.opacity(0.40)
    )
}

// MARK: - Hex helper

extension Color {
    /// Builds a colour from a 0xRRGGBB literal, matching the design tokens 1:1.
    init(hex: UInt32) {
        let red = Double((hex >> 16) & 0xFF) / 255
        let green = Double((hex >> 8) & 0xFF) / 255
        let blue = Double(hex & 0xFF) / 255
        self.init(.sRGB, red: red, green: green, blue: blue, opacity: 1)
    }
}

// MARK: - Environment plumbing

private struct PaletteKey: EnvironmentKey {
    static let defaultValue: Palette = .lightBlue
}

extension EnvironmentValues {
    /// The active palette. Injected once at the root and read by every view.
    var palette: Palette {
        get { self[PaletteKey.self] }
        set { self[PaletteKey.self] = newValue }
    }
}
