//
//  BrandLogo.swift
//  UNORMA
//
//  DESIGN SYSTEM — the original UNORMA mark and wordmark.
//
//  The mark is drawn entirely in code: a cradling arc (the "U" of UNORMA,
//  and the organization that holds its members) with three ascending dots
//  above it (the members themselves). No image assets required.
//

import SwiftUI

/// The cradle arc — an open bowl swept across the lower half of the frame.
struct CradleArc: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let center = CGPoint(x: rect.midX, y: rect.midY + rect.height * 0.04)
        let radius = min(rect.width, rect.height) * 0.32
        path.addArc(
            center: center,
            radius: radius,
            startAngle: .degrees(18),
            endAngle: .degrees(162),
            clockwise: false
        )
        return path
    }
}

/// The UNORMA symbol on its own, sized to whatever frame it is given.
struct UnormaMark: View {

    var size: CGFloat = 34
    var tint: Color = .white

    var body: some View {
        ZStack {
            CradleArc()
                .stroke(
                    tint,
                    style: StrokeStyle(lineWidth: size * 0.12, lineCap: .round)
                )

            // Three members rising out of the cradle.
            HStack(alignment: .bottom, spacing: size * 0.10) {
                dot(scale: 0.115)
                dot(scale: 0.155)
                dot(scale: 0.115)
            }
            .offset(y: -size * 0.20)
        }
        .frame(width: size, height: size)
    }

    private func dot(scale: CGFloat) -> some View {
        Circle()
            .fill(tint)
            .frame(width: size * scale, height: size * scale)
    }
}

/// The mark inside its rounded tile, as it appears on the auth header and splash.
struct UnormaLogoTile: View {

    var size: CGFloat = 62
    var tileOpacity: Double = 0.16

    var body: some View {
        RoundedRectangle(cornerRadius: size * 0.30, style: .continuous)
            .fill(.white.opacity(tileOpacity))
            .overlay(
                RoundedRectangle(cornerRadius: size * 0.30, style: .continuous)
                    .strokeBorder(.white.opacity(0.28), lineWidth: 1)
            )
            .overlay(UnormaMark(size: size * 0.56))
            .frame(width: size, height: size)
    }
}

/// "UNORMA" over its tracked-out tagline.
struct UnormaWordmark: View {

    var showsTagline: Bool = true
    var tint: Color = .white

    var body: some View {
        VStack(spacing: 6) {
            Text("UNORMA")
                .font(UNFont.wordmark)
                .tracking(3)
                .foregroundStyle(tint)

            if showsTagline {
                Text("UNIVERSITY ORGANIZATION MANAGER")
                    .font(.system(size: 10, weight: .medium))
                    .tracking(1.6)
                    .foregroundStyle(tint.opacity(0.66))
            }
        }
    }
}
