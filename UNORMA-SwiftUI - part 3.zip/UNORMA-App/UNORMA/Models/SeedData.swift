//
//  SeedData.swift
//  UNORMA
//
//  MODEL — the starter catalogue of organizations and events shipped with the app.
//  Kept out of the controllers so the data itself stays easy to edit.
//

import Foundation

enum SeedData {

    static let programs: [String] = [
        "BS Information Technology",
        "BS Computer Science",
        "BS Business Administration",
        "BS Psychology",
        "BS Civil Engineering",
        "BA Communication",
        "BS Nursing"
    ]

    static let organizations: [Organization] = [
        Organization(
            id: "SGA",
            name: "Student Government Association",
            emoji: "🏛️",
            category: .governance,
            foundedYear: 1962,
            meetingSchedule: "Mondays, 5 PM",
            advisorName: "Dean Olivia Reyes",
            advisorEmail: "o.reyes@crestview.edu",
            memberCount: 7,
            totalHeadcount: 204,
            isArchived: false,
            officers: [
                Officer(name: "Jordan Rivera", position: "President"),
                Officer(name: "Aaliyah Thompson", position: "Vice President"),
                Officer(name: "Marco Di Luca", position: "Secretary"),
                Officer(name: "Sophie Huang", position: "Treasurer"),
                Officer(name: "Kwame Asante", position: "PR Officer")
            ],
            committees: [
                Committee(name: "Academic Affairs", head: "Aaliyah Thompson", memberCount: 4),
                Committee(name: "Student Welfare", head: "Sophie Huang", memberCount: 3)
            ]
        ),
        Organization(
            id: "CSS",
            name: "Computer Science Society",
            emoji: "💻",
            category: .academic,
            foundedYear: 1998,
            meetingSchedule: "Wednesdays, 6 PM",
            advisorName: "Prof. Nathan Kim",
            advisorEmail: "n.kim@crestview.edu",
            memberCount: 6,
            totalHeadcount: 118,
            isArchived: false,
            officers: [
                Officer(name: "Priya Mehta", position: "President"),
                Officer(name: "Lucas Ferreira", position: "Vice President"),
                Officer(name: "Yuna Kim", position: "Secretary"),
                Officer(name: "Omar Hassan", position: "Treasurer"),
                Officer(name: "Avery Blake", position: "Workshop Director")
            ],
            committees: [
                Committee(name: "Hackathon Committee", head: "Avery Blake", memberCount: 3),
                Committee(name: "Mentorship Committee", head: "Yuna Kim", memberCount: 2)
            ]
        ),
        Organization(
            id: "FAC",
            name: "Fine Arts Collective",
            emoji: "🎨",
            category: .artsCulture,
            foundedYear: 2004,
            meetingSchedule: "Thursdays, 4 PM",
            advisorName: "Prof. Helena Cruz",
            advisorEmail: "h.cruz@crestview.edu",
            memberCount: 4,
            totalHeadcount: 76,
            isArchived: false,
            officers: [
                Officer(name: "Isabela Voss", position: "President"),
                Officer(name: "Marcus Wren", position: "Vice President"),
                Officer(name: "Tayo Okonkwo", position: "Events Director"),
                Officer(name: "Clara Song", position: "Treasurer")
            ],
            committees: [
                Committee(name: "Exhibit Committee", head: "Tayo Okonkwo", memberCount: 3)
            ]
        ),
        Organization(
            id: "EAC",
            name: "Environmental Action Club",
            emoji: "🌿",
            category: .advocacy,
            foundedYear: 2011,
            meetingSchedule: "Fridays, 3 PM",
            advisorName: "Dr. Ibrahim Salem",
            advisorEmail: "i.salem@crestview.edu",
            memberCount: 3,
            totalHeadcount: 54,
            isArchived: false,
            officers: [
                Officer(name: "Zara Ahmed", position: "President"),
                Officer(name: "Finn O'Connor", position: "Vice President"),
                Officer(name: "Lily Chen", position: "Secretary")
            ],
            committees: [
                Committee(name: "Campus Greening", head: "Lily Chen", memberCount: 2)
            ]
        ),
        Organization(
            id: "PLS",
            name: "Pre-Law Society",
            emoji: "⚖️",
            category: .academic,
            foundedYear: 1987,
            meetingSchedule: "Tuesdays, 5 PM",
            advisorName: "Atty. Grace Lim",
            advisorEmail: "g.lim@crestview.edu",
            memberCount: 3,
            totalHeadcount: 61,
            isArchived: false,
            officers: [
                Officer(name: "Naomi Steele", position: "President"),
                Officer(name: "Caden Wu", position: "Vice President"),
                Officer(name: "Imani Rhodes", position: "Secretary")
            ],
            committees: [
                Committee(name: "Moot Court", head: "Caden Wu", memberCount: 4)
            ]
        ),
        Organization(
            id: "ISA",
            name: "International Students Association",
            emoji: "🌍",
            category: .cultural,
            foundedYear: 2001,
            meetingSchedule: "Saturdays, 1 PM",
            advisorName: "Ms. Renata Alves",
            advisorEmail: "r.alves@crestview.edu",
            memberCount: 3,
            totalHeadcount: 89,
            isArchived: false,
            officers: [
                Officer(name: "Amara Diallo", position: "President"),
                Officer(name: "Hiroshi Tanaka", position: "Vice President"),
                Officer(name: "Sofia Mendoza", position: "Cultural Director")
            ],
            committees: [
                Committee(name: "Culture Night", head: "Sofia Mendoza", memberCount: 5)
            ]
        )
    ]

    static let events: [OrgEvent] = [
        OrgEvent(
            title: "Fall Town Hall",
            emoji: "🏛️",
            dateLabel: "Sep 12, 2025",
            timeLabel: "4:00–6:00 PM",
            location: "Main Auditorium",
            organizationID: "SGA",
            kind: "Town Hall",
            status: .upcoming,
            summary: "Open forum for students to raise concerns.",
            assignedRoles: [
                AssignedRole(roleName: "Moderator", personName: "Jordan Rivera", responsibility: "Facilitates discussion."),
                AssignedRole(roleName: "Note Taker", personName: "Marco Di Luca", responsibility: "Records minutes.")
            ]
        ),
        OrgEvent(
            title: "Club Funding Fair",
            emoji: "🎪",
            dateLabel: "Oct 3, 2025",
            timeLabel: "10:00 AM–2:00 PM",
            location: "Student Union Plaza",
            organizationID: "SGA",
            kind: "Fair",
            status: .upcoming,
            summary: "Meet the finance committee and walk through funding requests.",
            assignedRoles: [
                AssignedRole(roleName: "Lead Organizer", personName: "Sophie Huang", responsibility: "Coordinates booths.")
            ]
        ),
        OrgEvent(
            title: "Constitution Day Forum",
            emoji: "💬",
            dateLabel: "Aug 28, 2025",
            timeLabel: "2:00–4:00 PM",
            location: "Harris Hall 204",
            organizationID: "SGA",
            kind: "Forum",
            status: .completed,
            summary: "Annual review of the student constitution.",
            assignedRoles: [
                AssignedRole(roleName: "Speaker", personName: "Aaliyah Thompson", responsibility: "Presents amendments.")
            ]
        ),
        OrgEvent(
            title: "CrestHacks 2025",
            emoji: "⚡",
            dateLabel: "Nov 1–2, 2025",
            timeLabel: "9:00 AM onwards",
            location: "Engineering Complex",
            organizationID: "CSS",
            kind: "Hackathon",
            status: .upcoming,
            summary: "Two-day campus hackathon with mentors and prizes.",
            assignedRoles: [
                AssignedRole(roleName: "Lead Organizer", personName: "Avery Blake", responsibility: "Runs the schedule."),
                AssignedRole(roleName: "Judge Liaison", personName: "Priya Mehta", responsibility: "Coordinates judging.")
            ]
        ),
        OrgEvent(
            title: "Resume Workshop",
            emoji: "🛠️",
            dateLabel: "Sep 18, 2025",
            timeLabel: "5:00–7:00 PM",
            location: "Tech Lab B",
            organizationID: "CSS",
            kind: "Workshop",
            status: .ongoing,
            summary: "Hands-on resume review with alumni volunteers.",
            assignedRoles: [
                AssignedRole(roleName: "Facilitator", personName: "Yuna Kim", responsibility: "Leads the session.")
            ]
        ),
        OrgEvent(
            title: "Autumn Exhibit Opening",
            emoji: "🖼️",
            dateLabel: "Oct 10, 2025",
            timeLabel: "6:00–9:00 PM",
            location: "Crestview Gallery",
            organizationID: "FAC",
            kind: "Exhibit",
            status: .upcoming,
            summary: "Student showcase of paintings, prints and digital work.",
            assignedRoles: [
                AssignedRole(roleName: "Curator", personName: "Isabela Voss", responsibility: "Selects the works.")
            ]
        ),
        OrgEvent(
            title: "Campus Clean-Up Drive",
            emoji: "♻️",
            dateLabel: "Sep 27, 2025",
            timeLabel: "7:00–11:00 AM",
            location: "North Quad",
            organizationID: "EAC",
            kind: "Drive",
            status: .upcoming,
            summary: "Volunteer morning clean-up. Gloves and bags provided.",
            assignedRoles: [
                AssignedRole(roleName: "Team Lead", personName: "Zara Ahmed", responsibility: "Assigns zones.")
            ]
        ),
        OrgEvent(
            title: "Mock Trial Night",
            emoji: "⚖️",
            dateLabel: "Aug 15, 2025",
            timeLabel: "6:00–9:00 PM",
            location: "Moot Court Room",
            organizationID: "PLS",
            kind: "Competition",
            status: .completed,
            summary: "Inter-year mock trial with alumni judges.",
            assignedRoles: [
                AssignedRole(roleName: "Presiding Judge", personName: "Naomi Steele", responsibility: "Chairs the trial.")
            ]
        ),
        OrgEvent(
            title: "Culture Night",
            emoji: "🌍",
            dateLabel: "Nov 21, 2025",
            timeLabel: "5:00–10:00 PM",
            location: "Grand Ballroom",
            organizationID: "ISA",
            kind: "Showcase",
            status: .upcoming,
            summary: "Food, music and performances from twenty countries.",
            assignedRoles: [
                AssignedRole(roleName: "Host", personName: "Sofia Mendoza", responsibility: "Emcees the programme.")
            ]
        )
    ]

    /// Sample review queue so an Org Head account has something to act on.
    static func starterApplications() -> [MembershipApplication] {
        let calendar = Calendar.current
        func date(_ year: Int, _ month: Int, _ day: Int) -> Date {
            calendar.date(from: DateComponents(year: year, month: month, day: day)) ?? Date()
        }
        return [
            MembershipApplication(
                applicantID: UUID(),
                applicantName: "Mei Lin Cho",
                organizationID: "SGA",
                message: "I care deeply about student advocacy and want to contribute to Academic Affairs.",
                submittedOn: date(2025, 8, 22),
                status: .pending
            ),
            MembershipApplication(
                applicantID: UUID(),
                applicantName: "Alex Santos",
                organizationID: "CSS",
                message: "I am a sophomore CS major passionate about ML and want to join the Hackathon Committee.",
                submittedOn: date(2025, 8, 20),
                status: .pending
            ),
            MembershipApplication(
                applicantID: UUID(),
                applicantName: "Carlos Reyes",
                organizationID: "CSS",
                message: "Interested in the mentorship program as a junior who can give back.",
                submittedOn: date(2025, 8, 5),
                status: .rejected
            ),
            MembershipApplication(
                applicantID: UUID(),
                applicantName: "Alex Santos",
                organizationID: "FAC",
                message: "I have been doing digital art for years and believe FAC aligns with my creative ambitions.",
                submittedOn: date(2025, 8, 10),
                status: .approved
            )
        ]
    }
}
