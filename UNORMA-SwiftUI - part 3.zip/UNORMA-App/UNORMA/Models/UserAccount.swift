//
//  UserAccount.swift
//  UNORMA
//
//  MODEL — the persisted account record for a signed-up user.
//

import Foundation

/// The kind of account a person registers for.
enum UserRole: String, Codable, CaseIterable, Identifiable {
    case student
    case orgHead

    var id: String { rawValue }

    var title: String {
        switch self {
        case .student: return "Student"
        case .orgHead: return "Org Head"
        }
    }

    var subtitle: String {
        switch self {
        case .student: return "Apply to organizations"
        case .orgHead: return "Manage my organization"
        }
    }

    var glyph: String {
        switch self {
        case .student: return "graduationcap.fill"
        case .orgHead: return "building.columns.fill"
        }
    }

    /// Label shown on the profile / settings badge.
    var badgeLabel: String {
        switch self {
        case .student: return "Student"
        case .orgHead: return "Moderator"
        }
    }
}

/// Academic year levels offered on the register form.
enum YearLevel: String, Codable, CaseIterable, Identifiable {
    case first = "1st Year"
    case second = "2nd Year"
    case third = "3rd Year"
    case fourth = "4th Year"
    case fifth = "5th Year"
    case graduate = "Graduate"

    var id: String { rawValue }
}

/// A registered account. Passwords are never stored in the clear — only a salted digest.
struct UserAccount: Codable, Identifiable, Equatable {
    let id: UUID
    var fullName: String
    var email: String
    var passwordDigest: String
    var role: UserRole

    // Student-only fields
    var program: String?
    var yearLevel: YearLevel?

    // Org-head-only field: the organization this account manages.
    var managedOrganizationID: String?

    init(
        id: UUID = UUID(),
        fullName: String,
        email: String,
        passwordDigest: String,
        role: UserRole,
        program: String? = nil,
        yearLevel: YearLevel? = nil,
        managedOrganizationID: String? = nil
    ) {
        self.id = id
        self.fullName = fullName
        self.email = email
        self.passwordDigest = passwordDigest
        self.role = role
        self.program = program
        self.yearLevel = yearLevel
        self.managedOrganizationID = managedOrganizationID
    }

    /// "sam" -> "S". Used by the circular avatar throughout the app.
    var initials: String {
        let parts = fullName
            .split(separator: " ")
            .prefix(2)
            .compactMap { $0.first }
        let letters = String(parts).uppercased()
        return letters.isEmpty ? "?" : letters
    }

    /// "BS Information Technology — 3rd Year"
    var programLine: String? {
        guard let program, let yearLevel else { return nil }
        return "\(program) — \(yearLevel.rawValue)"
    }
}
