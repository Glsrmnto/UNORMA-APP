//
//  MembershipApplication.swift
//  UNORMA
//
//  MODEL — a student's application to join an organization.
//

import Foundation

enum ApplicationStatus: String, Codable, CaseIterable, Identifiable {
    case pending = "Pending"
    case approved = "Approved"
    case rejected = "Rejected"

    var id: String { rawValue }
}

struct MembershipApplication: Codable, Identifiable, Equatable {
    let id: UUID
    var applicantID: UUID
    var applicantName: String
    var organizationID: String
    var message: String
    var submittedOn: Date
    var status: ApplicationStatus

    init(
        id: UUID = UUID(),
        applicantID: UUID,
        applicantName: String,
        organizationID: String,
        message: String,
        submittedOn: Date = Date(),
        status: ApplicationStatus = .pending
    ) {
        self.id = id
        self.applicantID = applicantID
        self.applicantName = applicantName
        self.organizationID = organizationID
        self.message = message
        self.submittedOn = submittedOn
        self.status = status
    }

    var initials: String {
        let parts = applicantName.split(separator: " ").prefix(2).compactMap { $0.first }
        let letters = String(parts).uppercased()
        return letters.isEmpty ? "?" : letters
    }

    /// "Applied Sep 17, 2026"
    var submittedLabel: String {
        "Applied " + DateFormatter.unormaMedium.string(from: submittedOn)
    }
}

extension DateFormatter {
    /// Shared formatter so every date in the app reads the same way.
    static let unormaMedium: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMM d, yyyy"
        return formatter
    }()
}
