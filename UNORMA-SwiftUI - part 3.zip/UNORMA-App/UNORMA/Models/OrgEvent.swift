//
//  OrgEvent.swift
//  UNORMA
//
//  MODEL — an event hosted by an organization, plus its assigned roles.
//

import Foundation

enum EventStatus: String, Codable, CaseIterable, Identifiable {
    case upcoming = "Upcoming"
    case ongoing = "Ongoing"
    case completed = "Completed"

    var id: String { rawValue }
}

struct AssignedRole: Codable, Identifiable, Equatable {
    let id: UUID
    var roleName: String
    var personName: String
    var responsibility: String

    init(id: UUID = UUID(), roleName: String, personName: String, responsibility: String) {
        self.id = id
        self.roleName = roleName
        self.personName = personName
        self.responsibility = responsibility
    }

    var initials: String {
        let parts = personName.split(separator: " ").prefix(2).compactMap { $0.first }
        return String(parts).uppercased()
    }
}

struct OrgEvent: Codable, Identifiable, Equatable {
    let id: UUID
    var title: String
    var emoji: String
    var dateLabel: String
    var timeLabel: String
    var location: String
    var organizationID: String
    var kind: String
    var status: EventStatus
    var summary: String
    var assignedRoles: [AssignedRole]

    init(
        id: UUID = UUID(),
        title: String,
        emoji: String,
        dateLabel: String,
        timeLabel: String,
        location: String,
        organizationID: String,
        kind: String,
        status: EventStatus,
        summary: String,
        assignedRoles: [AssignedRole] = []
    ) {
        self.id = id
        self.title = title
        self.emoji = emoji
        self.dateLabel = dateLabel
        self.timeLabel = timeLabel
        self.location = location
        self.organizationID = organizationID
        self.kind = kind
        self.status = status
        self.summary = summary
        self.assignedRoles = assignedRoles
    }

    /// "Sep 12, 2025 · Main Auditorium"
    var subtitleLine: String { "\(dateLabel) · \(location)" }
}
