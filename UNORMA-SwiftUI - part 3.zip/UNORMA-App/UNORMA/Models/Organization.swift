//
//  Organization.swift
//  UNORMA
//
//  MODEL — a student organization plus its officers and committees.
//

import Foundation

enum OrgCategory: String, Codable, CaseIterable, Identifiable {
    case governance = "Governance"
    case academic = "Academic"
    case artsCulture = "Arts & Culture"
    case advocacy = "Advocacy"
    case cultural = "Cultural"

    var id: String { rawValue }
}

struct Officer: Codable, Identifiable, Equatable {
    let id: UUID
    var name: String
    var position: String
    var term: String

    init(id: UUID = UUID(), name: String, position: String, term: String = "2024–2025") {
        self.id = id
        self.name = name
        self.position = position
        self.term = term
    }

    var initials: String {
        let parts = name.split(separator: " ").prefix(2).compactMap { $0.first }
        return String(parts).uppercased()
    }
}

struct Committee: Codable, Identifiable, Equatable {
    let id: UUID
    var name: String
    var head: String
    var memberCount: Int

    init(id: UUID = UUID(), name: String, head: String, memberCount: Int) {
        self.id = id
        self.name = name
        self.head = head
        self.memberCount = memberCount
    }
}

struct Organization: Codable, Identifiable, Equatable {
    /// Stable short code — "SGA", "CSS". Doubles as the identifier.
    let id: String
    var name: String
    var emoji: String
    var category: OrgCategory
    var foundedYear: Int
    var meetingSchedule: String
    var advisorName: String
    var advisorEmail: String
    var memberCount: Int
    var totalHeadcount: Int
    var isArchived: Bool
    var officers: [Officer]
    var committees: [Committee]

    /// Accent colour picked on the "Create New" org form. Defaults to the brand blue.
    var colorHex: UInt32 = 0x5970E8

    var shortName: String { id }
    var establishedLine: String { "est. \(foundedYear) · \(totalHeadcount) members" }
}
