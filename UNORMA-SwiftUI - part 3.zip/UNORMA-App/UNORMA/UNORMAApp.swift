//
//  UNORMAApp.swift
//  UNORMA — University Organization Manager
//
//  App entry point. The three controllers are created once here and handed
//  down through the environment, which is what keeps the MVC seams clean:
//  models describe data, controllers own state and rules, views only render.
//

import SwiftUI

@main
struct UNORMAApp: App {

    @State private var auth = AuthController()
    @State private var data = DataController()
    @State private var theme = ThemeController()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environment(auth)
                .environment(data)
                .environment(theme)
                .environment(\.palette, theme.palette)
                .preferredColorScheme(theme.isDarkMode ? .dark : .light)
        }
    }
}
