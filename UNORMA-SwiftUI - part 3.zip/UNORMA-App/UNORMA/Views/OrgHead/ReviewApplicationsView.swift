//
//  ReviewApplicationsView.swift
//  UNORMA
//
//  VIEW — the Org Head review queue. Approving or rejecting writes straight
//  through the DataController, so the student's tracker updates with it.
//

import SwiftUI

struct ReviewApplicationsView: View {

    @Environment(AuthController.self) private var auth
    @Environment(DataController.self) private var data
    @Environment(\.palette) private var palette

    private var organization: Organization? {
        guard let id = auth.currentUser?.managedOrganizationID else { return nil }
        return data.organization(id: id)
    }

    private var queue: [MembershipApplication] {
        guard let organization else { return [] }
        return data.applications(forOrganization: organization.id)
    }

    private func items(_ status: ApplicationStatus) -> [MembershipApplication] {
        queue.filter { $0.status == status }
    }

    var body: some View {
        VStack(spacing: 0) {
            SectionTopBar(title: "Applications")

            ScrollView(showsIndicators: false) {
                if queue.isEmpty {
                    EmptyState(
                        emoji: "🗳️",
                        title: "Nothing to Review",
                        message: "New applications to your organization will appear here."
                    )
                    .screenInset()
                } else {
                    VStack(alignment: .leading, spacing: UNMetrics.sectionSpacing) {
                        if let organization { header(organization) }
                        group(title: "Pending", status: .pending)
                        group(title: "Approved", status: .approved)
                        group(title: "Rejected", status: .rejected)
                    }
                    .padding(.top, 18)
                    .padding(.bottom, 28)
                    .screenInset()
                }
            }
        }
        .toolbar(.hidden, for: .navigationBar)
        .animation(.easeInOut(duration: 0.26), value: queue)
    }

    // MARK: - Header

    private func header(_ organization: Organization) -> some View {
        UNCard(padding: 14) {
            HStack(spacing: 12) {
                EmojiBadge(emoji: organization.emoji, side: 42)

                VStack(alignment: .leading, spacing: 2) {
                    Text(organization.shortName)
                        .font(UNFont.sectionTitle)
                        .foregroundStyle(palette.ink)
                    Text("\(items(.pending).count) awaiting your decision")
                        .font(UNFont.caption)
                        .foregroundStyle(palette.inkSecondary)
                }

                Spacer(minLength: 0)

                StatTile(value: "\(queue.count)", caption: "Total")
                    .frame(width: 66)
            }
        }
    }

    // MARK: - Groups

    @ViewBuilder
    private func group(title: String, status: ApplicationStatus) -> some View {
        let list = items(status)
        if !list.isEmpty {
            VStack(alignment: .leading, spacing: 12) {
                SectionHeader(title: "\(title) (\(list.count))")

                ForEach(list) { application in
                    reviewCard(application)
                }
            }
        }
    }

    private func reviewCard(_ application: MembershipApplication) -> some View {
        UNCard(padding: 14) {
            VStack(alignment: .leading, spacing: 11) {
                HStack(spacing: 12) {
                    AvatarCircle(initials: application.initials)

                    VStack(alignment: .leading, spacing: 2) {
                        Text(application.applicantName)
                            .font(UNFont.cardTitle)
                            .foregroundStyle(palette.ink)
                        Text(application.submittedLabel)
                            .font(UNFont.caption)
                            .foregroundStyle(palette.inkSecondary)
                    }

                    Spacer(minLength: 0)

                    StatusTag.forApplication(application.status, palette: palette)
                }

                Text("“\(application.message)”")
                    .font(UNFont.caption)
                    .foregroundStyle(palette.inkSecondary)
                    .fixedSize(horizontal: false, vertical: true)

                if application.status == .pending {
                    HStack(spacing: 10) {
                        SecondaryButton(title: "Approve", tint: palette.success) {
                            decide(application, as: .approved)
                        }
                        SecondaryButton(title: "Reject", tint: palette.danger) {
                            decide(application, as: .rejected)
                        }
                    }
                }
            }
        }
    }

    private func decide(_ application: MembershipApplication, as status: ApplicationStatus) {
        withAnimation(.easeInOut(duration: 0.26)) {
            data.updateStatus(of: application.id, to: status)
        }
    }
}
