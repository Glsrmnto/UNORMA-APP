//
//  MyOrgView.swift
//  UNORMA
//
//  VIEW — the Org Head dashboard: the organization at a glance,
//  its key counts, and shortcuts into the review queue and events.
//

import SwiftUI

struct MyOrgView: View {

    @Environment(AuthController.self) private var auth
    @Environment(DataController.self) private var data
    @Environment(\.palette) private var palette

    var onJumpToTab: (String) -> Void

    private var organization: Organization? {
        guard let id = auth.currentUser?.managedOrganizationID else { return nil }
        return data.organization(id: id)
    }

    var body: some View {
        VStack(spacing: 0) {
            WelcomeHeader(name: auth.currentUser?.fullName ?? "there")

            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: UNMetrics.sectionSpacing) {
                    if let organization {
                        summaryRow(organization)
                        statsCard(organization)
                        officersPreview(organization)
                        quickActions(organization)
                    } else {
                        EmptyState(
                            emoji: "🏛️",
                            title: "No Organization Assigned",
                            message: "Your account is not linked to an organization yet."
                        )
                    }
                }
                .padding(.top, 18)
                .padding(.bottom, 28)
                .screenInset()
            }
        }
        .toolbar(.hidden, for: .navigationBar)
    }

    // MARK: - Summary

    private func summaryRow(_ organization: Organization) -> some View {
        HStack(spacing: 12) {
            NavigationLink(value: AppRoute.organization(organization.id)) {
                VStack(alignment: .leading, spacing: 8) {
                    Text("MY ORGANIZATION")
                        .font(.system(size: 9, weight: .bold))
                        .tracking(1.1)
                        .foregroundStyle(.white.opacity(0.75))
                        .padding(.horizontal, 9)
                        .padding(.vertical, 5)
                        .background(.white.opacity(0.16))
                        .clipShape(Capsule())

                    Text(organization.shortName)
                        .font(.system(size: 24, weight: .black, design: .rounded))
                        .foregroundStyle(.white)

                    Text("\(organization.totalHeadcount) members · \(organization.meetingSchedule)")
                        .font(.system(size: 12))
                        .foregroundStyle(.white.opacity(0.72))
                        .fixedSize(horizontal: false, vertical: true)
                }
                .padding(15)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(
                    ZStack {
                        palette.headerGradient
                        Circle()
                            .fill(.white.opacity(0.06))
                            .frame(width: 130, height: 130)
                            .offset(x: 70, y: -55)
                    }
                )
                .clipShape(RoundedRectangle(cornerRadius: UNMetrics.cardRadius, style: .continuous))
                .shadow(color: palette.accentDeep.opacity(0.25), radius: 12, x: 0, y: 5)
            }
            .buttonStyle(PressableStyle())

            UNCard(padding: 14) {
                VStack(spacing: 4) {
                    Text("\(upcomingCount(organization))")
                        .font(.system(size: 30, weight: .black, design: .rounded))
                        .foregroundStyle(palette.accent)
                    Text("Upcoming")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundStyle(palette.inkSecondary)
                }
                .frame(maxWidth: .infinity)
            }
            .frame(width: 92)
        }
        .fixedSize(horizontal: false, vertical: true)
    }

    // MARK: - Stats

    private func statsCard(_ organization: Organization) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionHeader(title: "Organization")

            UNCard(padding: 16) {
                HStack(spacing: 0) {
                    StatTile(value: "\(organization.officers.count)", caption: "Officers")
                    divider
                    StatTile(value: "\(organization.committees.count)", caption: "Committees")
                    divider
                    StatTile(value: "\(organization.memberCount)", caption: "Members")
                    divider
                    StatTile(value: "\(data.events(for: organization.id).count)", caption: "Events")
                }
            }
        }
    }

    private var divider: some View {
        Rectangle()
            .fill(palette.cardBorder)
            .frame(width: 1, height: 34)
    }

    // MARK: - Officers

    private func officersPreview(_ organization: Organization) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionHeader(title: "Officers", trailing: "\(organization.officers.count) total")

            VStack(spacing: 10) {
                ForEach(organization.officers.prefix(3)) { officer in
                    UNCard(padding: 12) {
                        HStack(spacing: 12) {
                            AvatarCircle(initials: officer.initials, diameter: 36)
                            VStack(alignment: .leading, spacing: 2) {
                                Text(officer.name)
                                    .font(UNFont.cardTitle)
                                    .foregroundStyle(palette.ink)
                                Text("\(officer.position) · \(officer.term)")
                                    .font(UNFont.caption)
                                    .foregroundStyle(palette.inkSecondary)
                            }
                            Spacer(minLength: 0)
                        }
                    }
                }
            }
        }
    }

    // MARK: - Quick actions

    private func quickActions(_ organization: Organization) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionHeader(title: "Quick Actions")

            HStack(spacing: 12) {
                QuickActionTile(
                    systemImage: "tray.full.fill",
                    title: "Applications",
                    subtitle: "\(pendingCount(organization)) pending"
                ) {
                    onJumpToTab(TabDestination.review.id)
                }

                QuickActionTile(
                    systemImage: "calendar",
                    title: "Manage Events",
                    subtitle: "\(data.events(for: organization.id).count) scheduled"
                ) {
                    onJumpToTab(TabDestination.events.id)
                }
            }
        }
    }

    // MARK: - Counts

    private func pendingCount(_ organization: Organization) -> Int {
        data.applications(forOrganization: organization.id)
            .filter { $0.status == .pending }
            .count
    }

    private func upcomingCount(_ organization: Organization) -> Int {
        data.events(for: organization.id)
            .filter { $0.status == .upcoming }
            .count
    }
}
