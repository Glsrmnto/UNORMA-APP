//
//  RootView.swift
//  UNORMA
//
//  VIEW — decides what the app shows: splash, the auth flow, or the tab shell.
//

import SwiftUI

struct RootView: View {

    @Environment(AuthController.self) private var auth
    @Environment(ThemeController.self) private var theme

    @State private var isShowingSplash = true

    var body: some View {
        ZStack {
            AppBackground()

            if isShowingSplash {
                SplashView()
                    .transition(.opacity)
            } else if auth.isSignedIn {
                MainTabView()
                    .transition(.asymmetric(
                        insertion: .opacity.combined(with: .scale(scale: 1.03)),
                        removal: .opacity
                    ))
            } else {
                AuthView()
                    .transition(.opacity)
            }
        }
        .animation(.easeInOut(duration: 0.38), value: isShowingSplash)
        .animation(.easeInOut(duration: 0.34), value: auth.isSignedIn)
        .task {
            try? await Task.sleep(nanoseconds: 2_100_000_000)
            isShowingSplash = false
        }
    }
}
