//
//  MyApplicationsView.swift
//  UNORMA
//
//  VIEW — the student's application tracker, grouped by status.
//

import SwiftUI

struct MyApplicationsView: View {

    @Environment(AuthController.self) private var auth
    @Environment(DataController.self) private var data
    @Environment(\.palette) private var palette

    private var applications: [MembershipApplication] {
        guard let user = auth.currentUser else { return [] }
        return data.applications(byApplicant: user.id)
    }

    private func applications(_ status: ApplicationStatus) -> [MembershipApplication] {
        applications.filter { $0.status == status }
    }

    var body: some View {
        VStack(spacing: 0) {
            SectionTopBar(title: "My Applications")

            ScrollView(showsIndicators: false) {
                if applications.isEmpty {
                    EmptyState(
                        emoji: "📋",
                        title: "No Applications Yet",
                        message: "Browse organizations and tap Apply to join clubs that interest you."
                    )
                    .screenInset()
                } else {
                    VStack(alignment: .leading, spacing: UNMetrics.sectionSpacing) {
                        summaryCard
                        group(title: "Pending", status: .pending)
                        group(title: "Approved", status: .approved)
                        group(title: "Rejected", status: .rejected)
                    }
                    .padding(.top, 18)
                    .padding(.bottom, 28)
                    .screenInset()
                }
            }
        }
        .toolbar(.hidden, for: .navigationBar)
        .animation(.easeInOut(duration: 0.24), value: applications.count)
    }

    // MARK: - Summary

    private var summaryCard: some View {
        UNCard {
            HStack(spacing: 12) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("\(applications.count) Submitted")
                        .font(.system(size: 19, weight: .bold, design: .rounded))
                        .foregroundStyle(palette.ink)

                    Text("\(applications(.approved).count) approved · \(applications(.pending).count) pending")
                        .font(UNFont.caption)
                        .foregroundStyle(palette.inkSecondary)
                }

                Spacer(minLength: 0)

                StatTile(value: "\(applications(.approved).count)", caption: "Approved")
                    .frame(width: 78)
            }
        }
    }

    // MARK: - Grouping

    @ViewBuilder
    private func group(title: String, status: ApplicationStatus) -> some View {
        let items = applications(status)
        if !items.isEmpty {
            VStack(alignment: .leading, spacing: 12) {
                SectionHeader(title: "\(title) (\(items.count))")

                ForEach(items) { application in
                    applicationCard(application)
                }
            }
        }
    }

    private func applicationCard(_ application: MembershipApplication) -> some View {
        let organization = data.organization(id: application.organizationID)

        return UNCard(padding: 14) {
            VStack(alignment: .leading, spacing: 11) {
                HStack(spacing: 12) {
                    EmojiBadge(emoji: organization?.emoji ?? "🏷️", side: 42)

                    VStack(alignment: .leading, spacing: 2) {
                        Text(organization?.name ?? application.organizationID)
                            .font(UNFont.cardTitle)
                            .foregroundStyle(palette.ink)
                            .fixedSize(horizontal: false, vertical: true)

                        Text(application.submittedLabel)
                            .font(UNFont.caption)
                            .foregroundStyle(palette.inkSecondary)
                    }

                    Spacer(minLength: 0)

                    StatusTag.forApplication(application.status, palette: palette)
                }

                Text("“\(application.message)”")
                    .font(UNFont.caption)
                    .foregroundStyle(palette.inkSecondary)
                    .fixedSize(horizontal: false, vertical: true)

                if application.status == .pending {
                    SecondaryButton(title: "Withdraw Application", tint: palette.danger) {
                        withAnimation(.easeInOut(duration: 0.24)) {
                            data.withdrawApplication(id: application.id)
                        }
                    }
                }
            }
        }
    }
}
