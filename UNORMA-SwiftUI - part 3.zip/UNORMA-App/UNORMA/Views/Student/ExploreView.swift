//
//  ExploreView.swift
//  UNORMA
//
//  VIEW — the student home tab: greeting, hero card, search, category filter,
//  the organization grid and quick actions.
//

import SwiftUI

struct ExploreView: View {

    @Environment(AuthController.self) private var auth
    @Environment(DataController.self) private var data
    @Environment(\.palette) private var palette

    /// Lets the hero and quick-action tiles switch the bottom tab.
    var onJumpToTab: (String) -> Void

    @State private var query = ""
    @State private var categoryIndex = 0

    private var categoryTitles: [String] {
        ["All"] + OrgCategory.allCases.map(\.rawValue)
    }

    private var selectedCategory: OrgCategory? {
        categoryIndex == 0 ? nil : OrgCategory.allCases[categoryIndex - 1]
    }

    private var results: [Organization] {
        data.organizations(matching: query, category: selectedCategory)
    }

    private let gridColumns = Array(repeating: GridItem(.flexible(), spacing: 10), count: 4)

    var body: some View {
        VStack(spacing: 0) {
            WelcomeHeader(name: auth.currentUser?.fullName ?? "there")

            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: UNMetrics.sectionSpacing) {
                    heroRow.screenInset()

                    SearchField(placeholder: "Search organizations…", text: $query)
                        .screenInset()

                    FilterChipRow(titles: categoryTitles, selection: $categoryIndex)

                    organizationGrid.screenInset()

                    quickActions.screenInset()
                }
                .padding(.top, 18)
                .padding(.bottom, 28)
            }
        }
        .toolbar(.hidden, for: .navigationBar)
    }

    // MARK: - Hero

    private var heroRow: some View {
        HStack(spacing: 12) {
            Button {
                onJumpToTab(TabDestination.events.id)
            } label: {
                VStack(alignment: .leading, spacing: 8) {
                    Text("GET STARTED")
                        .font(.system(size: 9, weight: .bold))
                        .tracking(1.1)
                        .foregroundStyle(.white.opacity(0.75))
                        .padding(.horizontal, 9)
                        .padding(.vertical, 5)
                        .background(.white.opacity(0.16))
                        .clipShape(Capsule())

                    Text("Explore Organizations")
                        .font(.system(size: 18, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                        .multilineTextAlignment(.leading)

                    Text("Find clubs and activities that match your interests")
                        .font(.system(size: 12))
                        .foregroundStyle(.white.opacity(0.7))
                        .fixedSize(horizontal: false, vertical: true)

                    Circle()
                        .fill(.white.opacity(0.18))
                        .frame(width: 28, height: 28)
                        .overlay(
                            Image(systemName: "chevron.right")
                                .font(.system(size: 12, weight: .bold))
                                .foregroundStyle(.white)
                        )
                        .padding(.top, 2)
                }
                .padding(15)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(
                    ZStack {
                        palette.headerGradient
                        Circle()
                            .fill(.white.opacity(0.06))
                            .frame(width: 130, height: 130)
                            .offset(x: 70, y: -55)
                    }
                )
                .clipShape(RoundedRectangle(cornerRadius: UNMetrics.cardRadius, style: .continuous))
                .shadow(color: palette.accentDeep.opacity(0.25), radius: 12, x: 0, y: 5)
            }
            .buttonStyle(PressableStyle())

            UNCard(padding: 14) {
                VStack(spacing: 4) {
                    Text("\(data.organizations.count)")
                        .font(.system(size: 30, weight: .black, design: .rounded))
                        .foregroundStyle(palette.accent)
                    Text("Available")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundStyle(palette.inkSecondary)
                }
                .frame(maxWidth: .infinity)
            }
            .frame(width: 92)
        }
        .fixedSize(horizontal: false, vertical: true)
    }

    // MARK: - Grid

    private var organizationGrid: some View {
        VStack(alignment: .leading, spacing: 14) {
            SectionHeader(title: "Organizations", trailing: "\(results.count) shown")

            if results.isEmpty {
                EmptyState(
                    emoji: "🔍",
                    title: "No matches",
                    message: "Try a different search term or category filter."
                )
            } else {
                LazyVGrid(columns: gridColumns, spacing: 16) {
                    ForEach(results) { organization in
                        NavigationLink(value: AppRoute.organization(organization.id)) {
                            OrganizationTile(organization: organization)
                        }
                        .buttonStyle(PressableStyle())
                    }
                }
            }
        }
    }

    // MARK: - Quick actions

    private var quickActions: some View {
        VStack(alignment: .leading, spacing: 14) {
            SectionHeader(title: "Quick Actions")

            HStack(spacing: 12) {
                QuickActionTile(
                    systemImage: "doc.text.fill",
                    title: "My Applications",
                    subtitle: "\(submittedCount) submitted"
                ) {
                    onJumpToTab(TabDestination.myApps.id)
                }

                QuickActionTile(
                    systemImage: "calendar",
                    title: "Browse Events",
                    subtitle: "Upcoming events"
                ) {
                    onJumpToTab(TabDestination.events.id)
                }
            }
        }
    }

    private var submittedCount: Int {
        guard let user = auth.currentUser else { return 0 }
        return data.applications(byApplicant: user.id).count
    }
}

/// One square in the organization grid.
struct OrganizationTile: View {

    @Environment(\.palette) private var palette

    let organization: Organization

    var body: some View {
        VStack(spacing: 6) {
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .fill(Color(hex: organization.colorHex).opacity(0.16))
                .frame(height: 60)
                .overlay(
                    Text(organization.emoji).font(.system(size: 26))
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .strokeBorder(Color(hex: organization.colorHex).opacity(0.25), lineWidth: 1)
                )

            Text(organization.shortName)
                .font(.system(size: 11, weight: .bold))
                .foregroundStyle(palette.ink)
                .lineLimit(1)
                .minimumScaleFactor(0.7)
        }
    }
}
