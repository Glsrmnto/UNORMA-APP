//
//  OrganizationDetailView.swift
//  UNORMA
//
//  VIEW — a single organization: header, apply action, and the
//  Overview / Officers / Committees / Events tab strip.
//

import SwiftUI

struct OrganizationDetailView: View {

    @Environment(AuthController.self) private var auth
    @Environment(DataController.self) private var data
    @Environment(\.palette) private var palette
    @Environment(\.dismiss) private var dismiss

    let organizationID: String

    @State private var tabIndex = 0
    @State private var isApplying = false
    @State private var applicationMessage = ""

    private let tabTitles = ["Overview", "Officers", "Committees", "Events"]

    private var organization: Organization? {
        data.organization(id: organizationID)
    }

    private var existingApplication: MembershipApplication? {
        guard let user = auth.currentUser else { return nil }
        return data.application(by: user.id, organizationID: organizationID)
    }

    var body: some View {
        ZStack {
            AppBackground()

            VStack(spacing: 0) {
                DetailTopBar(contextLabel: "Explore", subtitle: nil) { dismiss() }

                if let organization {
                    ScrollView(showsIndicators: false) {
                        VStack(alignment: .leading, spacing: UNMetrics.sectionSpacing) {
                            identityCard(organization)
                            applySection(organization)
                            FilterChipRow(titles: tabTitles, selection: $tabIndex)
                                .padding(.horizontal, -UNMetrics.screenPadding)
                            tabContent(organization)
                        }
                        .padding(.top, 18)
                        .padding(.bottom, 32)
                        .screenInset()
                    }
                } else {
                    EmptyState(
                        emoji: "🏚️",
                        title: "Organization unavailable",
                        message: "This organization is no longer listed."
                    )
                    Spacer()
                }
            }
        }
        .toolbar(.hidden, for: .navigationBar)
        .edgeSwipeBack { dismiss() }
        .animation(.easeInOut(duration: 0.22), value: tabIndex)
        .animation(.easeInOut(duration: 0.22), value: isApplying)
    }

    // MARK: - Header card

    private func identityCard(_ organization: Organization) -> some View {
        UNCard {
            HStack(spacing: 13) {
                EmojiBadge(emoji: organization.emoji, side: 54)

                VStack(alignment: .leading, spacing: 3) {
                    Text(organization.name)
                        .font(UNFont.screenTitle)
                        .foregroundStyle(palette.ink)
                        .fixedSize(horizontal: false, vertical: true)

                    Text(organization.establishedLine)
                        .font(UNFont.caption)
                        .foregroundStyle(palette.inkSecondary)

                    StatusTag(
                        text: organization.category.rawValue,
                        foreground: palette.accent,
                        background: palette.accentSoft
                    )
                    .padding(.top, 3)
                }

                Spacer(minLength: 0)
            }
        }
    }

    // MARK: - Apply

    @ViewBuilder
    private func applySection(_ organization: Organization) -> some View {
        if let existingApplication {
            UNCard(padding: 14) {
                HStack(spacing: 10) {
                    StatusTag.forApplication(existingApplication.status, palette: palette)
                    Text("Submitted \(DateFormatter.unormaMedium.string(from: existingApplication.submittedOn))")
                        .font(UNFont.caption)
                        .foregroundStyle(palette.inkSecondary)
                    Spacer(minLength: 0)
                }
            }
        } else if isApplying {
            UNCard {
                VStack(alignment: .leading, spacing: 12) {
                    Text("Apply to \(organization.shortName)")
                        .font(UNFont.sectionTitle)
                        .foregroundStyle(palette.ink)

                    Text("Why do you want to join?")
                        .font(UNFont.captionMedium)
                        .foregroundStyle(palette.accent)

                    TextEditor(text: $applicationMessage)
                        .font(UNFont.body)
                        .foregroundStyle(palette.ink)
                        .scrollContentBackground(.hidden)
                        .frame(height: 96)
                        .padding(9)
                        .background(palette.input)
                        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 12, style: .continuous)
                                .strokeBorder(palette.inputBorder, lineWidth: 1)
                        )

                    HStack(spacing: 10) {
                        SecondaryButton(title: "Cancel", tint: palette.inkSecondary, height: 50) {
                            isApplying = false
                            applicationMessage = ""
                        }
                        PrimaryButton(title: "Submit", action: submitApplication)
                    }
                }
            }
        } else {
            PrimaryButton(
                title: "Apply to Join \(organization.shortName)",
                systemImage: "paperplane.fill"
            ) {
                isApplying = true
            }
        }
    }

    private func submitApplication() {
        guard let user = auth.currentUser else { return }
        data.submitApplication(
            applicant: user,
            organizationID: organizationID,
            message: applicationMessage
        )
        isApplying = false
        applicationMessage = ""
    }

    // MARK: - Tabs

    @ViewBuilder
    private func tabContent(_ organization: Organization) -> some View {
        switch tabIndex {
        case 1: officersTab(organization)
        case 2: committeesTab(organization)
        case 3: eventsTab(organization)
        default: overviewTab(organization)
        }
    }

    private func overviewTab(_ organization: Organization) -> some View {
        UNCard(padding: 16) {
            VStack(spacing: 0) {
                InfoRow(label: "Category", value: organization.category.rawValue)
                InfoRow(label: "Founded", value: String(organization.foundedYear))
                InfoRow(label: "Meets", value: organization.meetingSchedule)
                InfoRow(label: "Advisor", value: organization.advisorName)
                InfoRow(label: "Members", value: "\(organization.totalHeadcount)", isLast: true)
            }
        }
    }

    private func officersTab(_ organization: Organization) -> some View {
        VStack(spacing: 10) {
            ForEach(organization.officers) { officer in
                UNCard(padding: 13) {
                    HStack(spacing: 12) {
                        AvatarCircle(initials: officer.initials)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(officer.name)
                                .font(UNFont.cardTitle)
                                .foregroundStyle(palette.ink)
                            Text("\(officer.position) · \(officer.term)")
                                .font(UNFont.caption)
                                .foregroundStyle(palette.inkSecondary)
                        }
                        Spacer(minLength: 0)
                    }
                }
            }

            UNCard(padding: 13) {
                HStack(spacing: 12) {
                    EmojiBadge(emoji: "🎓", side: 38)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(organization.advisorName)
                            .font(UNFont.cardTitle)
                            .foregroundStyle(palette.ink)
                        Text("Faculty Advisor · \(organization.advisorEmail)")
                            .font(UNFont.caption)
                            .foregroundStyle(palette.inkSecondary)
                    }
                    Spacer(minLength: 0)
                }
            }
        }
    }

    @ViewBuilder
    private func committeesTab(_ organization: Organization) -> some View {
        if organization.committees.isEmpty {
            EmptyState(
                emoji: "🗂️",
                title: "No Committees Yet",
                message: "This organization has not published any committees."
            )
        } else {
            VStack(spacing: 10) {
                ForEach(organization.committees) { committee in
                    UNCard(padding: 14) {
                        VStack(alignment: .leading, spacing: 3) {
                            Text(committee.name)
                                .font(UNFont.cardTitle)
                                .foregroundStyle(palette.ink)
                            Text("Head: \(committee.head) · \(committee.memberCount) members")
                                .font(UNFont.caption)
                                .foregroundStyle(palette.inkSecondary)
                        }
                    }
                }
            }
        }
    }

    @ViewBuilder
    private func eventsTab(_ organization: Organization) -> some View {
        let events = data.events(for: organization.id)
        if events.isEmpty {
            EmptyState(
                emoji: "📅",
                title: "No Events Scheduled",
                message: "Check back once this organization posts its calendar."
            )
        } else {
            VStack(spacing: 10) {
                ForEach(events) { event in
                    NavigationLink(value: AppRoute.event(event.id)) {
                        EventRow(event: event, organization: organization)
                    }
                    .buttonStyle(PressableStyle())
                }
            }
        }
    }
}
