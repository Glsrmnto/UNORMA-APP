//
//  SplashView.swift
//  UNORMA
//
//  VIEW — the launch screen: the mark draws itself in, the wordmark rises,
//  and a thin progress bar fills while the controllers restore their state.
//

import SwiftUI

struct SplashView: View {

    @Environment(\.palette) private var palette

    @State private var markScale: CGFloat = 0.55
    @State private var markOpacity: Double = 0
    @State private var haloScale: CGFloat = 0.7
    @State private var haloOpacity: Double = 0
    @State private var wordmarkOffset: CGFloat = 18
    @State private var wordmarkOpacity: Double = 0
    @State private var progress: CGFloat = 0

    var body: some View {
        ZStack {
            // Full-bleed brand gradient with soft ambient orbs.
            palette.headerGradient
                .ignoresSafeArea()

            Circle()
                .fill(.white.opacity(0.06))
                .frame(width: 300, height: 300)
                .blur(radius: 10)
                .offset(x: 130, y: -260)

            Circle()
                .stroke(.white.opacity(0.06), lineWidth: 40)
                .frame(width: 420, height: 420)
                .offset(x: -150, y: 260)

            VStack(spacing: 26) {
                Spacer()

                ZStack {
                    // Expanding halo behind the logo tile.
                    Circle()
                        .stroke(.white.opacity(0.25), lineWidth: 1.5)
                        .frame(width: 128, height: 128)
                        .scaleEffect(haloScale)
                        .opacity(haloOpacity)

                    UnormaLogoTile(size: 84, tileOpacity: 0.18)
                        .scaleEffect(markScale)
                        .opacity(markOpacity)
                }

                UnormaWordmark()
                    .offset(y: wordmarkOffset)
                    .opacity(wordmarkOpacity)

                Spacer()

                // Determinate-looking loading bar.
                ZStack(alignment: .leading) {
                    Capsule()
                        .fill(.white.opacity(0.18))
                        .frame(width: 132, height: 4)
                    Capsule()
                        .fill(.white.opacity(0.9))
                        .frame(width: 132 * progress, height: 4)
                }
                .padding(.bottom, 54)
                .opacity(wordmarkOpacity)
            }
        }
        .onAppear(perform: runAnimation)
    }

    private func runAnimation() {
        withAnimation(.spring(response: 0.62, dampingFraction: 0.60)) {
            markScale = 1
            markOpacity = 1
        }
        haloOpacity = 0.85
        withAnimation(.easeOut(duration: 1.20).delay(0.22)) {
            haloScale = 1.55
            haloOpacity = 0
        }
        withAnimation(.easeOut(duration: 0.55).delay(0.34)) {
            wordmarkOffset = 0
            wordmarkOpacity = 1
        }
        withAnimation(.easeInOut(duration: 1.35).delay(0.50)) {
            progress = 1
        }
    }
}
