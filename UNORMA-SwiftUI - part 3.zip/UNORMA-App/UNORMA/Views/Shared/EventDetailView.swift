//
//  EventDetailView.swift
//  UNORMA
//
//  VIEW — a single event: summary, details block, assigned roles and RSVP.
//

import SwiftUI

struct EventDetailView: View {

    @Environment(DataController.self) private var data
    @Environment(\.palette) private var palette
    @Environment(\.dismiss) private var dismiss

    let eventID: UUID

    private var event: OrgEvent? { data.event(id: eventID) }

    var body: some View {
        ZStack {
            AppBackground()

            VStack(spacing: 0) {
                DetailTopBar(contextLabel: "Events", subtitle: nil) { dismiss() }

                if let event {
                    ScrollView(showsIndicators: false) {
                        VStack(alignment: .leading, spacing: UNMetrics.sectionSpacing) {
                            headerCard(event)
                            detailsCard(event)
                            rolesSection(event)
                        }
                        .padding(.top, 18)
                        .padding(.bottom, 32)
                        .screenInset()
                    }
                } else {
                    EmptyState(
                        emoji: "📭",
                        title: "Event unavailable",
                        message: "This event is no longer on the calendar."
                    )
                    Spacer()
                }
            }
        }
        .toolbar(.hidden, for: .navigationBar)
        .edgeSwipeBack { dismiss() }
    }

    // MARK: - Header

    private func headerCard(_ event: OrgEvent) -> some View {
        UNCard {
            VStack(alignment: .leading, spacing: 13) {
                HStack(spacing: 13) {
                    EmojiBadge(emoji: event.emoji, side: 52)

                    VStack(alignment: .leading, spacing: 5) {
                        StatusTag.forEvent(event.status, palette: palette)
                        Text(event.title)
                            .font(UNFont.screenTitle)
                            .foregroundStyle(palette.ink)
                            .fixedSize(horizontal: false, vertical: true)
                    }

                    Spacer(minLength: 0)
                }

                Text(event.summary)
                    .font(UNFont.body)
                    .foregroundStyle(palette.inkSecondary)
                    .fixedSize(horizontal: false, vertical: true)

                Button {
                    withAnimation(.spring(response: 0.3, dampingFraction: 0.75)) {
                        data.toggleRSVP(event.id)
                    }
                } label: {
                    HStack(spacing: 7) {
                        Image(systemName: data.isRSVPd(event.id) ? "checkmark.circle.fill" : "plus.circle")
                            .font(.system(size: 15, weight: .bold))
                        Text(data.isRSVPd(event.id) ? "RSVP'd" : "RSVP")
                            .font(.system(size: 15, weight: .bold, design: .rounded))
                    }
                    .foregroundStyle(data.isRSVPd(event.id) ? palette.success : .white)
                    .frame(maxWidth: .infinity)
                    .frame(height: 46)
                    .background {
                        if data.isRSVPd(event.id) {
                            RoundedRectangle(cornerRadius: 13, style: .continuous)
                                .fill(palette.successSoft)
                        } else {
                            RoundedRectangle(cornerRadius: 13, style: .continuous)
                                .fill(palette.primaryButtonGradient)
                        }
                    }
                }
                .buttonStyle(PressableStyle())
            }
        }
    }

    // MARK: - Details

    private func detailsCard(_ event: OrgEvent) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionHeader(title: "Event Details")

            UNCard(padding: 16) {
                VStack(spacing: 0) {
                    InfoRow(label: "Date", value: event.dateLabel)
                    InfoRow(label: "Time", value: event.timeLabel)
                    InfoRow(label: "Location", value: event.location)
                    InfoRow(
                        label: "Hosted by",
                        value: data.organization(id: event.organizationID)?.name ?? event.organizationID,
                        isLast: true
                    )
                }
            }
        }
    }

    // MARK: - Roles

    @ViewBuilder
    private func rolesSection(_ event: OrgEvent) -> some View {
        if !event.assignedRoles.isEmpty {
            VStack(alignment: .leading, spacing: 12) {
                SectionHeader(title: "Assigned Roles (\(event.assignedRoles.count))")

                ForEach(event.assignedRoles) { role in
                    UNCard(padding: 13) {
                        VStack(alignment: .leading, spacing: 8) {
                            HStack(spacing: 12) {
                                AvatarCircle(initials: role.initials)
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(role.roleName)
                                        .font(UNFont.captionMedium)
                                        .foregroundStyle(palette.accent)
                                    Text(role.personName)
                                        .font(UNFont.cardTitle)
                                        .foregroundStyle(palette.ink)
                                }
                                Spacer(minLength: 0)
                            }

                            Text(role.responsibility)
                                .font(UNFont.caption)
                                .foregroundStyle(palette.inkSecondary)
                        }
                    }
                }
            }
        }
    }
}
