//
//  EventsView.swift
//  UNORMA
//
//  VIEW — the Events tab: All Events / My Events, a "Next Up" spotlight,
//  status filtering and the full event list.
//

import SwiftUI

struct EventsView: View {

    @Environment(DataController.self) private var data
    @Environment(\.palette) private var palette

    @State private var scopeIndex = 0        // 0 = All Events, 1 = My Events
    @State private var statusIndex = 0

    private var statusTitles: [String] {
        ["All"] + EventStatus.allCases.map(\.rawValue)
    }

    private var selectedStatus: EventStatus? {
        statusIndex == 0 ? nil : EventStatus.allCases[statusIndex - 1]
    }

    private var listedEvents: [OrgEvent] {
        let base = scopeIndex == 0 ? data.events : data.rsvpdEvents
        guard let selectedStatus else { return base }
        return base.filter { $0.status == selectedStatus }
    }

    var body: some View {
        VStack(spacing: 0) {
            SectionTopBar(title: "Events")

            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: UNMetrics.sectionSpacing) {
                    SegmentedToggle(
                        options: ["All Events", myEventsLabel],
                        selection: $scopeIndex,
                        onLightBackground: true
                    )
                    .screenInset()

                    if scopeIndex == 0, let next = data.nextUpEvent {
                        nextUpCard(next).screenInset()
                    }

                    if scopeIndex == 0 {
                        FilterChipRow(titles: statusTitles, selection: $statusIndex)
                    }

                    eventList.screenInset()
                }
                .padding(.top, 18)
                .padding(.bottom, 28)
            }
        }
        .toolbar(.hidden, for: .navigationBar)
        .animation(.easeInOut(duration: 0.24), value: scopeIndex)
        .animation(.easeInOut(duration: 0.24), value: statusIndex)
    }

    private var myEventsLabel: String {
        let count = data.rsvpdEvents.count
        return count == 0 ? "My Events" : "My Events (\(count))"
    }

    // MARK: - Next up

    private func nextUpCard(_ event: OrgEvent) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            SectionHeader(title: "Next Up")

            NavigationLink(value: AppRoute.event(event.id)) {
                HStack(spacing: 13) {
                    EmojiBadge(emoji: event.emoji, side: 48)

                    VStack(alignment: .leading, spacing: 4) {
                        Text(event.title)
                            .font(.system(size: 17, weight: .bold, design: .rounded))
                            .foregroundStyle(.white)
                        Text(event.subtitleLine)
                            .font(UNFont.caption)
                            .foregroundStyle(.white.opacity(0.75))
                        HStack(spacing: 6) {
                            StatusTag(
                                text: event.organizationID,
                                foreground: .white,
                                background: .white.opacity(0.18)
                            )
                            StatusTag(
                                text: event.kind,
                                foreground: .white,
                                background: .white.opacity(0.18)
                            )
                        }
                    }

                    Spacer(minLength: 0)
                }
                .padding(14)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(
                    ZStack {
                        palette.headerGradient
                        Circle()
                            .fill(.white.opacity(0.06))
                            .frame(width: 150, height: 150)
                            .offset(x: 120, y: -50)
                    }
                )
                .clipShape(RoundedRectangle(cornerRadius: UNMetrics.cardRadius, style: .continuous))
                .shadow(color: palette.accentDeep.opacity(0.25), radius: 12, x: 0, y: 5)
            }
            .buttonStyle(PressableStyle())
        }
    }

    // MARK: - List

    @ViewBuilder
    private var eventList: some View {
        if listedEvents.isEmpty {
            EmptyState(
                emoji: scopeIndex == 0 ? "🗓️" : "📅",
                title: scopeIndex == 0 ? "No Events Found" : "No RSVP'd Events",
                message: scopeIndex == 0
                    ? "Try a different status filter."
                    : "Browse events and tap RSVP to save them here."
            )
        } else {
            VStack(alignment: .leading, spacing: 12) {
                SectionHeader(title: "\(listedEvents.count) Events")

                ForEach(listedEvents) { event in
                    NavigationLink(value: AppRoute.event(event.id)) {
                        EventRow(
                            event: event,
                            organization: data.organization(id: event.organizationID),
                            showsRSVPBadge: data.isRSVPd(event.id)
                        )
                    }
                    .buttonStyle(PressableStyle())
                }
            }
        }
    }
}
