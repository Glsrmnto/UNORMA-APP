//
//  ProfileView.swift
//  UNORMA
//
//  VIEW — the Profile tab for students and the Settings tab for org heads.
//  Identity card, appearance toggle, account summary and sign out.
//

import SwiftUI

struct ProfileView: View {

    @Environment(AuthController.self) private var auth
    @Environment(DataController.self) private var data
    @Environment(ThemeController.self) private var theme
    @Environment(\.palette) private var palette

    @State private var isEditing = false
    @State private var draftName = ""
    @State private var draftProgram: String?
    @State private var draftYearLevel: String?
    @State private var isConfirmingSignOut = false

    private var user: UserAccount? { auth.currentUser }

    private var screenTitle: String {
        user?.role == .orgHead ? "Settings" : "Profile"
    }

    var body: some View {
        VStack(spacing: 0) {
            SectionTopBar(title: screenTitle)

            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: UNMetrics.sectionSpacing) {
                    if let user {
                        identityCard(user)
                        if isEditing { editCard(user) }
                        appearanceSection
                        accountSection(user)
                        signOutButton
                    }
                }
                .padding(.top, 18)
                .padding(.bottom, 28)
                .screenInset()
            }
        }
        .toolbar(.hidden, for: .navigationBar)
        .animation(.easeInOut(duration: 0.24), value: isEditing)
        .alert("Sign out of UNORMA?", isPresented: $isConfirmingSignOut) {
            Button("Cancel", role: .cancel) { }
            Button("Sign Out", role: .destructive) { auth.signOut() }
        } message: {
            Text("Your account stays saved on this device.")
        }
    }

    // MARK: - Identity

    private func identityCard(_ user: UserAccount) -> some View {
        ZStack(alignment: .topTrailing) {
            VStack(alignment: .leading, spacing: 12) {
                HStack(spacing: 13) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 16, style: .continuous)
                            .fill(.white.opacity(0.18))
                            .frame(width: 58, height: 58)
                        Text(user.initials)
                            .font(.system(size: 24, weight: .bold, design: .rounded))
                            .foregroundStyle(.white)
                    }

                    VStack(alignment: .leading, spacing: 3) {
                        Text(user.fullName)
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(.white)
                            .lineLimit(1)

                        Text(user.email)
                            .font(UNFont.caption)
                            .foregroundStyle(.white.opacity(0.75))
                            .lineLimit(1)

                        StatusTag(
                            text: user.role.badgeLabel,
                            foreground: .white,
                            background: .white.opacity(0.20)
                        )
                    }

                    Spacer(minLength: 54)
                }

                if let programLine = user.programLine {
                    Text(programLine)
                        .font(UNFont.caption)
                        .foregroundStyle(.white.opacity(0.75))
                } else if let orgID = user.managedOrganizationID,
                          let organization = data.organization(id: orgID) {
                    Text("Manages \(organization.name)")
                        .font(UNFont.caption)
                        .foregroundStyle(.white.opacity(0.75))
                }
            }
            .padding(16)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(
                ZStack {
                    palette.headerGradient
                    Circle()
                        .fill(.white.opacity(0.06))
                        .frame(width: 160, height: 160)
                        .offset(x: 120, y: -60)
                }
            )
            .clipShape(RoundedRectangle(cornerRadius: UNMetrics.cardRadius, style: .continuous))
            .shadow(color: palette.accentDeep.opacity(0.25), radius: 12, x: 0, y: 5)

            Button {
                beginEditing(user)
            } label: {
                Text(isEditing ? "Close" : "Edit")
                    .font(.system(size: 13, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 15)
                    .padding(.vertical, 8)
                    .background(.white.opacity(0.20))
                    .clipShape(Capsule())
            }
            .buttonStyle(PressableStyle())
            .padding(14)
        }
    }

    private func beginEditing(_ user: UserAccount) {
        if !isEditing {
            draftName = user.fullName
            draftProgram = user.program
            draftYearLevel = user.yearLevel?.rawValue
        }
        isEditing.toggle()
    }

    // MARK: - Edit

    private func editCard(_ user: UserAccount) -> some View {
        UNCard {
            VStack(alignment: .leading, spacing: 15) {
                Text("Edit Profile")
                    .font(UNFont.sectionTitle)
                    .foregroundStyle(palette.ink)

                UNTextField(
                    label: "Full Name",
                    placeholder: "Your name",
                    text: $draftName,
                    capitalization: .words
                )

                if user.role == .student {
                    UNMenuField(
                        label: "Program",
                        placeholder: "Select your program…",
                        options: SeedData.programs,
                        selection: $draftProgram
                    )

                    ChoiceGrid(
                        label: "Year Level",
                        options: YearLevel.allCases.map(\.rawValue),
                        selection: $draftYearLevel
                    )
                }

                PrimaryButton(title: "Save Changes") {
                    auth.updateCurrentUser(
                        fullName: draftName,
                        program: draftProgram,
                        yearLevel: draftYearLevel.flatMap(YearLevel.init(rawValue:))
                    )
                    isEditing = false
                }
            }
        }
    }

    // MARK: - Appearance

    private var appearanceSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionHeader(title: "Appearance")

            UNCard(padding: 14) {
                HStack(spacing: 12) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 11, style: .continuous)
                            .fill(palette.accentDeep)
                            .frame(width: 38, height: 38)
                        Image(systemName: theme.isDarkMode ? "moon.stars.fill" : "sun.max.fill")
                            .font(.system(size: 16))
                            .foregroundStyle(.white)
                    }

                    VStack(alignment: .leading, spacing: 2) {
                        Text("Dark Mode")
                            .font(UNFont.cardTitle)
                            .foregroundStyle(palette.ink)
                        Text(theme.appearanceSubtitle)
                            .font(UNFont.caption)
                            .foregroundStyle(palette.inkSecondary)
                    }

                    Spacer(minLength: 0)

                    Toggle("", isOn: Bindable(theme).isDarkMode)
                        .labelsHidden()
                        .tint(palette.accent)
                }
            }
        }
    }

    // MARK: - Account

    private func accountSection(_ user: UserAccount) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionHeader(title: "Account")

            UNCard(padding: 16) {
                VStack(spacing: 0) {
                    if let programLine = user.programLine {
                        InfoRow(label: "Program", value: programLine)
                    }
                    if let orgID = user.managedOrganizationID {
                        InfoRow(
                            label: "Organization",
                            value: data.organization(id: orgID)?.name ?? orgID
                        )
                    }
                    InfoRow(label: "Role", value: user.role.badgeLabel)
                    InfoRow(label: "Email", value: user.email, isLast: true)
                }
            }
        }
    }

    // MARK: - Sign out

    private var signOutButton: some View {
        Button {
            isConfirmingSignOut = true
        } label: {
            Text("Sign Out")
                .font(.system(size: 16, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity)
                .frame(height: 50)
                .background(palette.danger)
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                .shadow(color: palette.danger.opacity(0.28), radius: 10, x: 0, y: 5)
        }
        .buttonStyle(PressableStyle())
        .padding(.top, 4)
    }
}
