//
//  EventRow.swift
//  UNORMA
//
//  VIEW — the reusable event list row shared by the Events tab,
//  the organization detail screen and the dashboards.
//

import SwiftUI

struct EventRow: View {

    @Environment(\.palette) private var palette

    let event: OrgEvent
    let organization: Organization?
    var showsRSVPBadge: Bool = false

    var body: some View {
        UNCard(padding: 13) {
            HStack(spacing: 12) {
                EmojiBadge(emoji: event.emoji, side: 44)

                VStack(alignment: .leading, spacing: 5) {
                    Text(event.title)
                        .font(UNFont.cardTitle)
                        .foregroundStyle(palette.ink)
                        .lineLimit(1)

                    Text(event.subtitleLine)
                        .font(UNFont.caption)
                        .foregroundStyle(palette.inkSecondary)
                        .lineLimit(1)

                    HStack(spacing: 6) {
                        StatusTag.forEvent(event.status, palette: palette)

                        StatusTag(
                            text: organization?.shortName ?? event.organizationID,
                            foreground: palette.inkSecondary,
                            background: palette.inkSecondary.opacity(0.12)
                        )

                        if showsRSVPBadge {
                            StatusTag(
                                text: "RSVP'd",
                                foreground: palette.success,
                                background: palette.successSoft
                            )
                        }
                    }
                }

                Spacer(minLength: 0)

                Image(systemName: "chevron.right")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(palette.inkSecondary.opacity(0.5))
            }
        }
    }
}
