//
//  TabDestination.swift
//  UNORMA
//
//  MODEL (navigation) — the tab sets and push destinations used by the shell.
//

import Foundation

/// A single slot in the bottom navigation bar.
struct TabDestination: Identifiable, Hashable {
    let id: String
    let title: String
    let icon: String
    let selectedIcon: String

    static let explore = TabDestination(
        id: "explore", title: "Explore",
        icon: "building.columns", selectedIcon: "building.columns.fill"
    )
    static let myApps = TabDestination(
        id: "myApps", title: "My Apps",
        icon: "doc.text", selectedIcon: "doc.text.fill"
    )
    static let events = TabDestination(
        id: "events", title: "Events",
        icon: "calendar", selectedIcon: "calendar"
    )
    static let profile = TabDestination(
        id: "profile", title: "Profile",
        icon: "person", selectedIcon: "person.fill"
    )
    static let myOrg = TabDestination(
        id: "myOrg", title: "My Org",
        icon: "flag", selectedIcon: "flag.fill"
    )
    static let review = TabDestination(
        id: "review", title: "Applications",
        icon: "tray", selectedIcon: "tray.full.fill"
    )
    static let settings = TabDestination(
        id: "settings", title: "Settings",
        icon: "gearshape", selectedIcon: "gearshape.fill"
    )

    /// The tab bar a given role sees.
    static func tabs(for role: UserRole) -> [TabDestination] {
        switch role {
        case .student: return [.explore, .myApps, .events, .profile]
        case .orgHead: return [.myOrg, .review, .events, .settings]
        }
    }
}

/// Everything that can be pushed on top of a tab.
enum AppRoute: Hashable {
    case organization(String)
    case event(UUID)
}
