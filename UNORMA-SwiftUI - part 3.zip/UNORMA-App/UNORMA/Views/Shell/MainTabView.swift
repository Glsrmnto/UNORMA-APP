//
//  MainTabView.swift
//  UNORMA
//
//  VIEW — the signed-in shell. Chooses the tab set for the account's role,
//  keeps each tab's navigation stack alive, and animates between them.
//

import SwiftUI

struct MainTabView: View {

    @Environment(AuthController.self) private var auth
    @Environment(DataController.self) private var data
    @Environment(\.palette) private var palette

    @State private var selection: String = TabDestination.explore.id

    private var role: UserRole { auth.currentUser?.role ?? .student }
    private var tabs: [TabDestination] { TabDestination.tabs(for: role) }

    private var selectedIndex: Int {
        tabs.firstIndex { $0.id == selection } ?? 0
    }

    var body: some View {
        ZStack {
            AppBackground()

            VStack(spacing: 0) {
                ZStack {
                    ForEach(Array(tabs.enumerated()), id: \.element.id) { index, tab in
                        screen(for: tab)
                            .opacity(tab.id == selection ? 1 : 0)
                            .scaleEffect(tab.id == selection ? 1 : 0.985)
                            .offset(x: offset(for: index))
                            .allowsHitTesting(tab.id == selection)
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)

                UNTabBar(tabs: tabs, selection: $selection, badges: badges)
            }
        }
        .animation(.easeInOut(duration: 0.26), value: selection)
        .onAppear(perform: syncSelectionToRole)
        .onChange(of: role) { _, _ in syncSelectionToRole() }
    }

    // MARK: - Layout helpers

    /// Slides the outgoing tab a little in the direction it left.
    private func offset(for index: Int) -> CGFloat {
        guard index != selectedIndex else { return 0 }
        return index < selectedIndex ? -14 : 14
    }

    /// Keeps the selected tab valid when the role (and therefore the tab set) changes.
    private func syncSelectionToRole() {
        if !tabs.contains(where: { $0.id == selection }) {
            selection = tabs.first?.id ?? TabDestination.explore.id
        }
    }

    private var badges: [String: Int] {
        guard let user = auth.currentUser else { return [:] }
        switch user.role {
        case .student:
            let pending = data.applications(byApplicant: user.id)
                .filter { $0.status == .pending }.count
            return [TabDestination.myApps.id: pending]
        case .orgHead:
            guard let orgID = user.managedOrganizationID else { return [:] }
            let pending = data.applications(forOrganization: orgID)
                .filter { $0.status == .pending }.count
            return [TabDestination.review.id: pending]
        }
    }

    // MARK: - Routing

    @ViewBuilder
    private func screen(for tab: TabDestination) -> some View {
        switch tab.id {
        case TabDestination.explore.id:
            NavigationStack { ExploreView(onJumpToTab: { selection = $0 }).routed() }
        case TabDestination.myApps.id:
            NavigationStack { MyApplicationsView().routed() }
        case TabDestination.events.id:
            NavigationStack { EventsView().routed() }
        case TabDestination.profile.id, TabDestination.settings.id:
            NavigationStack { ProfileView().routed() }
        case TabDestination.myOrg.id:
            NavigationStack { MyOrgView(onJumpToTab: { selection = $0 }).routed() }
        case TabDestination.review.id:
            NavigationStack { ReviewApplicationsView().routed() }
        default:
            EmptyView()
        }
    }
}

// MARK: - Shared destinations

private struct RoutedModifier: ViewModifier {
    func body(content: Content) -> some View {
        content
            .navigationDestination(for: AppRoute.self) { route in
                switch route {
                case .organization(let id):
                    OrganizationDetailView(organizationID: id)
                case .event(let id):
                    EventDetailView(eventID: id)
                }
            }
    }
}

extension View {
    /// Registers the push destinations every tab shares.
    func routed() -> some View { modifier(RoutedModifier()) }
}
