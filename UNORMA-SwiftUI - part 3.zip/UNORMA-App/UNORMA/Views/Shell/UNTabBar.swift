//
//  UNTabBar.swift
//  UNORMA
//
//  VIEW — the custom bottom navigation bar with a sliding selection indicator.
//

import SwiftUI

struct UNTabBar: View {

    @Environment(\.palette) private var palette

    let tabs: [TabDestination]
    @Binding var selection: String
    /// Optional badge counts keyed by tab id.
    var badges: [String: Int] = [:]

    private var selectedIndex: Int {
        tabs.firstIndex { $0.id == selection } ?? 0
    }

    var body: some View {
        GeometryReader { proxy in
            let itemWidth = proxy.size.width / CGFloat(max(tabs.count, 1))

            // `.topLeading` matters: with a top-centred stack every child is
            // horizontally centred before the offset is applied, so the pill
            // and the indicator drifted further off the further a tab sat
            // from the middle. Anchoring to the leading edge makes the offset
            // an absolute position, which lines both up with the item exactly.
            ZStack(alignment: .topLeading) {
                let pillWidth = max(itemWidth - 20, 0)
                let indicatorWidth: CGFloat = 26

                // Sliding pill behind the active item.
                Capsule()
                    .fill(palette.accentSoft)
                    .frame(width: pillWidth, height: 38)
                    .offset(
                        x: itemWidth * CGFloat(selectedIndex) + (itemWidth - pillWidth) / 2,
                        y: 6
                    )

                // Top edge indicator.
                Capsule()
                    .fill(palette.accent)
                    .frame(width: indicatorWidth, height: 3)
                    .offset(
                        x: itemWidth * CGFloat(selectedIndex) + (itemWidth - indicatorWidth) / 2,
                        y: 0
                    )

                HStack(spacing: 0) {
                    ForEach(tabs) { tab in
                        tabButton(for: tab, width: itemWidth)
                    }
                }
            }
        }
        .frame(height: UNMetrics.tabBarHeight)
        .background(
            palette.tabBar
                .background(.ultraThinMaterial)
                .overlay(alignment: .top) {
                    Rectangle()
                        .fill(palette.tabBarBorder)
                        .frame(height: 1)
                }
        )
        .animation(.spring(response: 0.36, dampingFraction: 0.78), value: selection)
    }

    // MARK: - Item

    private func tabButton(for tab: TabDestination, width: CGFloat) -> some View {
        let isSelected = tab.id == selection

        return Button {
            guard !isSelected else { return }
            selection = tab.id
        } label: {
            VStack(spacing: 3) {
                ZStack(alignment: .topTrailing) {
                    Image(systemName: isSelected ? tab.selectedIcon : tab.icon)
                        .font(.system(size: 17, weight: isSelected ? .semibold : .regular))
                        .foregroundStyle(isSelected ? palette.accent : palette.inkSecondary.opacity(0.65))
                        .scaleEffect(isSelected ? 1.08 : 1)

                    if let count = badges[tab.id], count > 0 {
                        Text("\(min(count, 99))")
                            .font(.system(size: 9, weight: .bold))
                            .foregroundStyle(.white)
                            .frame(minWidth: 15, minHeight: 15)
                            .background(Circle().fill(palette.danger))
                            .offset(x: 11, y: -6)
                    }
                }
                .frame(height: 22)

                Text(tab.title)
                    .font(UNFont.tabLabel)
                    .foregroundStyle(isSelected ? palette.accent : palette.inkSecondary.opacity(0.65))
                    .lineLimit(1)
                    .minimumScaleFactor(0.8)
            }
            .frame(width: width, height: UNMetrics.tabBarHeight - 8)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}
