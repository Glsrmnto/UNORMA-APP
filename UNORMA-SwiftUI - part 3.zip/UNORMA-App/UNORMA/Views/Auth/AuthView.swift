//
//  AuthView.swift
//  UNORMA
//
//  VIEW — the signed-out container: brand header, Sign In / Register toggle,
//  and the "account created" confirmation that hands off to the tab shell.
//

import SwiftUI

struct AuthView: View {

    @Environment(AuthController.self) private var auth

    @State private var selectedTab = 0
    @State private var createdAccount: UserAccount?

    var body: some View {
        ZStack {
            AppBackground()

            VStack(spacing: 0) {
                header

                if let createdAccount {
                    AccountCreatedView(account: createdAccount)
                        .transition(.opacity.combined(with: .move(edge: .bottom)))
                } else {
                    ScrollView(showsIndicators: false) {
                        VStack(spacing: 0) {
                            if selectedTab == 0 {
                                SignInFormView()
                                    .transition(.asymmetric(
                                        insertion: .move(edge: .leading).combined(with: .opacity),
                                        removal: .move(edge: .leading).combined(with: .opacity)
                                    ))
                            } else {
                                RegisterFormView { account in
                                    withAnimation(.easeInOut(duration: 0.3)) {
                                        createdAccount = account
                                    }
                                    Task { await completeSignIn(for: account) }
                                }
                                .transition(.asymmetric(
                                    insertion: .move(edge: .trailing).combined(with: .opacity),
                                    removal: .move(edge: .trailing).combined(with: .opacity)
                                ))
                            }
                        }
                        .padding(.top, 18)
                        .padding(.bottom, 36)
                        .screenInset()
                    }
                }
            }
        }
        .animation(.easeInOut(duration: 0.28), value: selectedTab)
    }

    // MARK: - Header

    private var header: some View {
        GradientHeader(minHeight: 248) {
            VStack(spacing: 16) {
                UnormaLogoTile(size: 60)
                UnormaWordmark()

                SegmentedToggle(
                    options: ["Sign In", "Register"],
                    selection: $selectedTab
                )
                .screenInset()
                .padding(.top, 4)
                .opacity(createdAccount == nil ? 1 : 0.55)
                .disabled(createdAccount != nil)
            }
            .padding(.top, 22)
            .padding(.bottom, 20)
        }
    }

    // MARK: - Flow

    /// Lets the confirmation card breathe for a moment, then opens the session.
    private func completeSignIn(for account: UserAccount) async {
        try? await Task.sleep(nanoseconds: 1_500_000_000)
        auth.activate(account)
    }
}

/// The "Welcome, sam!" confirmation shown right after registering.
private struct AccountCreatedView: View {

    @Environment(\.palette) private var palette

    let account: UserAccount

    @State private var badgeScale: CGFloat = 0.6

    var body: some View {
        VStack(spacing: 14) {
            Spacer().frame(height: 60)

            ZStack {
                Circle()
                    .fill(palette.successSoft)
                    .frame(width: 78, height: 78)
                Image(systemName: "checkmark")
                    .font(.system(size: 30, weight: .bold))
                    .foregroundStyle(palette.success)
            }
            .scaleEffect(badgeScale)

            Text("Welcome, \(account.fullName)!")
                .font(.system(size: 20, weight: .bold, design: .rounded))
                .foregroundStyle(palette.ink)

            Text("Your account has been created.")
                .font(UNFont.body)
                .foregroundStyle(palette.inkSecondary)

            HStack(spacing: 7) {
                ProgressView().scaleEffect(0.7)
                Text("Signing you in…")
                    .font(UNFont.caption)
                    .foregroundStyle(palette.inkSecondary)
            }
            .padding(.top, 6)

            Spacer()
        }
        .frame(maxWidth: .infinity)
        .onAppear {
            withAnimation(.spring(response: 0.5, dampingFraction: 0.55)) {
                badgeScale = 1
            }
        }
    }
}
