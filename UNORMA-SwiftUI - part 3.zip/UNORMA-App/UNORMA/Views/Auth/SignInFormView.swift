//
//  SignInFormView.swift
//  UNORMA
//
//  VIEW — email + password sign-in, validated against the stored accounts.
//

import SwiftUI

struct SignInFormView: View {

    @Environment(AuthController.self) private var auth
    @Environment(\.palette) private var palette

    @State private var email = ""
    @State private var password = ""
    @State private var errorMessage: String?

    var body: some View {
        VStack(spacing: 16) {
            UNCard(padding: 18) {
                VStack(spacing: 16) {
                    UNTextField(
                        label: "Email Address",
                        placeholder: "yourname@crestview.edu",
                        text: $email,
                        keyboard: .emailAddress,
                        capitalization: .never,
                        uppercasedLabel: true
                    )

                    UNSecureField(
                        label: "Password",
                        placeholder: "••••••••",
                        text: $password
                    )

                    if let errorMessage {
                        ErrorBanner(message: errorMessage)
                    }

                    PrimaryButton(title: "Sign In", action: submit)
                        .padding(.top, 2)
                }
            }

            Text("Use the Register tab to create a new account.")
                .font(UNFont.caption)
                .foregroundStyle(palette.inkSecondary.opacity(0.85))
                .multilineTextAlignment(.center)
                .padding(.top, 2)
        }
        .animation(.easeOut(duration: 0.2), value: errorMessage)
    }

    private func submit() {
        do {
            try auth.signIn(email: email, password: password)
            errorMessage = nil
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}
