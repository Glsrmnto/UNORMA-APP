//
//  RegisterFormView.swift
//  UNORMA
//
//  VIEW — the full registration form. Student and Org Head paths each reveal
//  their own fields; everything is validated by AuthController before saving.
//

import SwiftUI

struct RegisterFormView: View {

    @Environment(AuthController.self) private var auth
    @Environment(DataController.self) private var data
    @Environment(\.palette) private var palette

    /// Handed the freshly created account so the parent can show the welcome card.
    var onRegistered: (UserAccount) -> Void

    // Shared fields
    @State private var role: UserRole = .student
    @State private var fullName = ""
    @State private var email = ""
    @State private var password = ""
    @State private var confirmPassword = ""
    @State private var errorMessage: String?

    // Student fields
    @State private var program: String?
    @State private var yearLevel: String?

    // Org Head fields
    @State private var orgMode = 0                 // 0 = Select Existing, 1 = Create New
    @State private var existingOrgName: String?
    @State private var newOrgName = ""
    @State private var newOrgShortName = ""
    @State private var newOrgCategory: String? = OrgCategory.academic.rawValue
    @State private var selectedColorIndex = 0

    private let swatches: [UInt32] = [
        0x5970E8, 0x22B8F0, 0x8B5CF6, 0xEC4899,
        0x10B981, 0xE08A16, 0x0C1F6E
    ]

    var body: some View {
        UNCard(padding: 18) {
            VStack(alignment: .leading, spacing: 18) {
                Text("Create your account")
                    .font(UNFont.screenTitle)
                    .foregroundStyle(palette.ink)

                rolePicker

                UNTextField(
                    label: "Full Name",
                    placeholder: "e.g. Alex Santos",
                    text: $fullName,
                    capitalization: .words,
                    uppercasedLabel: true
                )

                if role == .student {
                    studentFields
                        .transition(.opacity)
                } else {
                    orgHeadFields
                        .transition(.opacity)
                }

                UNTextField(
                    label: "Email Address",
                    placeholder: "yourname@crestview.edu",
                    text: $email,
                    keyboard: .emailAddress,
                    capitalization: .never,
                    uppercasedLabel: true
                )

                UNSecureField(
                    label: "Password",
                    placeholder: "At least 6 characters",
                    text: $password
                )

                UNSecureField(
                    label: "Confirm Password",
                    placeholder: "Re-enter your password",
                    text: $confirmPassword
                )

                if let errorMessage {
                    ErrorBanner(message: errorMessage)
                }

                PrimaryButton(title: "Create Account", action: submit)

                Text("By registering you agree to the UNORMA terms of use.")
                    .font(.system(size: 11))
                    .foregroundStyle(palette.inkSecondary.opacity(0.85))
                    .frame(maxWidth: .infinity, alignment: .center)
            }
        }
        .animation(.easeInOut(duration: 0.22), value: role)
        .animation(.easeInOut(duration: 0.22), value: orgMode)
        .animation(.easeOut(duration: 0.2), value: errorMessage)
    }

    // MARK: - Role

    private var rolePicker: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("I am joining as a…")
                .font(UNFont.captionMedium)
                .foregroundStyle(palette.accent)

            HStack(spacing: 10) {
                ForEach(UserRole.allCases) { option in
                    RoleSelectionCard(role: option, isSelected: role == option) {
                        role = option
                    }
                }
            }
        }
    }

    // MARK: - Student path

    private var studentFields: some View {
        VStack(alignment: .leading, spacing: 18) {
            UNMenuField(
                label: "Program",
                placeholder: "Select your program…",
                options: SeedData.programs,
                selection: $program
            )

            ChoiceGrid(
                label: "Year Level",
                options: YearLevel.allCases.map(\.rawValue),
                selection: $yearLevel
            )
        }
    }

    // MARK: - Org Head path

    private var orgHeadFields: some View {
        VStack(alignment: .leading, spacing: 14) {
            FieldLabel(text: "Organization")

            SegmentedToggle(
                options: ["Select Existing", "Create New"],
                selection: $orgMode,
                onLightBackground: true
            )

            if orgMode == 0 {
                UNMenuField(
                    label: "",
                    placeholder: "Select your organization…",
                    options: data.organizations.map(\.name),
                    selection: $existingOrgName
                )
            } else {
                VStack(alignment: .leading, spacing: 14) {
                    UNTextField(
                        label: "",
                        placeholder: "Organization full name",
                        text: $newOrgName,
                        capitalization: .words
                    )

                    UNTextField(
                        label: "",
                        placeholder: "Short name / abbreviation — optional",
                        text: $newOrgShortName,
                        capitalization: .characters
                    )

                    UNMenuField(
                        label: "Category",
                        placeholder: "Select a category…",
                        options: OrgCategory.allCases.map(\.rawValue),
                        selection: $newOrgCategory
                    )

                    colorSwatches
                    photoUploadPlaceholder
                }
            }

            NoticeBanner(message: "Org Head accounts can only manage their assigned organization.")
        }
    }

    private var colorSwatches: some View {
        VStack(alignment: .leading, spacing: 8) {
            FieldLabel(text: "Org Color")

            HStack(spacing: 9) {
                ForEach(Array(swatches.enumerated()), id: \.offset) { index, hex in
                    Button {
                        withAnimation(.easeOut(duration: 0.16)) { selectedColorIndex = index }
                    } label: {
                        Circle()
                            .fill(Color(hex: hex))
                            .frame(width: 30, height: 30)
                            .overlay {
                                if selectedColorIndex == index {
                                    Image(systemName: "checkmark")
                                        .font(.system(size: 12, weight: .bold))
                                        .foregroundStyle(.white)
                                }
                            }
                            .overlay(
                                Circle().strokeBorder(
                                    selectedColorIndex == index ? palette.ink.opacity(0.35) : .clear,
                                    lineWidth: 2
                                )
                            )
                    }
                    .buttonStyle(PressableStyle())
                }
            }
        }
    }

    private var photoUploadPlaceholder: some View {
        VStack(alignment: .leading, spacing: 8) {
            FieldLabel(text: "Organization Photo")

            HStack(spacing: 12) {
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .fill(palette.accentSoft)
                    .frame(width: 52, height: 52)
                    .overlay(
                        Image(systemName: "camera.fill")
                            .font(.system(size: 17))
                            .foregroundStyle(palette.accent)
                    )

                VStack(alignment: .leading, spacing: 2) {
                    Text("Tap to upload a photo")
                        .font(UNFont.bodyMedium)
                        .foregroundStyle(palette.ink)
                    Text("PNG, JPG from your gallery")
                        .font(.system(size: 11))
                        .foregroundStyle(palette.inkSecondary)
                }

                Spacer()
            }
            .padding(11)
            .background(palette.input)
            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .strokeBorder(palette.inputBorder, style: StrokeStyle(lineWidth: 1, dash: [5, 4]))
            )
        }
    }

    // MARK: - Submit

    private func submit() {
        var rollbackOrganizationID: String?

        do {
            let managedID = try resolveManagedOrganizationID()
            if orgMode == 1, role == .orgHead { rollbackOrganizationID = managedID }

            let account = try auth.register(
                fullName: fullName,
                email: email,
                password: password,
                confirmPassword: confirmPassword,
                role: role,
                program: program,
                yearLevel: yearLevel.flatMap(YearLevel.init(rawValue:)),
                managedOrganizationID: managedID
            )

            errorMessage = nil
            onRegistered(account)
        } catch {
            // Undo the placeholder organization if the account itself was rejected.
            if let rollbackOrganizationID {
                data.removeOrganization(id: rollbackOrganizationID)
            }
            errorMessage = error.localizedDescription
        }
    }

    /// Resolves — and if necessary creates — the organization an Org Head will manage.
    private func resolveManagedOrganizationID() throws -> String? {
        guard role == .orgHead else { return nil }

        if orgMode == 0 {
            guard let existingOrgName,
                  let match = data.organizations.first(where: { $0.name == existingOrgName })
            else { throw AuthError.missingOrganization }
            return match.id
        }

        guard !newOrgName.trimmed.isEmpty else { throw AuthError.missingOrganization }
        let category = newOrgCategory.flatMap(OrgCategory.init(rawValue:)) ?? .academic
        let created = data.createOrganization(
            name: newOrgName,
            shortName: newOrgShortName,
            emoji: "🏷️",
            category: category,
            colorHex: swatches[selectedColorIndex],
            headName: fullName.trimmed.isEmpty ? "Org Head" : fullName.trimmed
        )
        return created.id
    }
}
