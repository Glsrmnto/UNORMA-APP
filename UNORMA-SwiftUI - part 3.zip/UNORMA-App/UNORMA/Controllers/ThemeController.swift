//
//  ThemeController.swift
//  UNORMA
//
//  CONTROLLER — holds the light / midnight-blue appearance choice and remembers it.
//

import Foundation
import Observation

@Observable
final class ThemeController {

    var isDarkMode: Bool {
        didSet { store.setBool(isDarkMode, forKey: StorageKey.isDarkMode) }
    }

    private let store: PersistenceStore

    init(store: PersistenceStore = PersistenceStore()) {
        self.store = store
        self.isDarkMode = store.bool(forKey: StorageKey.isDarkMode, fallback: false)
    }

    /// Subtitle shown under "Dark Mode" on the profile screen.
    var appearanceSubtitle: String {
        isDarkMode ? "On — midnight blue" : "Off — light blue"
    }

    var palette: Palette {
        isDarkMode ? .midnight : .lightBlue
    }
}
