//
//  PersistenceStore.swift
//  UNORMA
//
//  CONTROLLER (support) — a thin, typed wrapper over UserDefaults so the
//  controllers never deal with encoding details directly.
//

import Foundation

enum StorageKey {
    static let accounts = "unorma.accounts"
    static let currentUserID = "unorma.currentUserID"
    static let applications = "unorma.applications"
    static let rsvpEventIDs = "unorma.rsvpEventIDs"
    static let isDarkMode = "unorma.isDarkMode"
}

struct PersistenceStore {

    private let defaults: UserDefaults
    private let encoder = JSONEncoder()
    private let decoder = JSONDecoder()

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
    }

    /// Reads and decodes a value, returning `fallback` when absent or unreadable.
    func load<T: Decodable>(_ type: T.Type, forKey key: String, fallback: T) -> T {
        guard let data = defaults.data(forKey: key) else { return fallback }
        guard let decoded = try? decoder.decode(T.self, from: data) else { return fallback }
        return decoded
    }

    /// Encodes and writes a value. Silently no-ops if the value cannot be encoded.
    func save<T: Encodable>(_ value: T, forKey key: String) {
        guard let data = try? encoder.encode(value) else { return }
        defaults.set(data, forKey: key)
    }

    func bool(forKey key: String, fallback: Bool = false) -> Bool {
        defaults.object(forKey: key) == nil ? fallback : defaults.bool(forKey: key)
    }

    func setBool(_ value: Bool, forKey key: String) {
        defaults.set(value, forKey: key)
    }

    func remove(forKey key: String) {
        defaults.removeObject(forKey: key)
    }
}
