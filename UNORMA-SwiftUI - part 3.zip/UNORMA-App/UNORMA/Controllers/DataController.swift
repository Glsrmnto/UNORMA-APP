//
//  DataController.swift
//  UNORMA
//
//  CONTROLLER — the single source of truth for organizations, events,
//  applications and RSVPs. Applications and RSVPs are persisted.
//

import Foundation
import Observation

@Observable
final class DataController {

    // MARK: - State

    private(set) var organizations: [Organization] = SeedData.organizations
    private(set) var events: [OrgEvent] = SeedData.events
    private(set) var applications: [MembershipApplication] = []
    private(set) var rsvpEventIDs: Set<UUID> = []

    // MARK: - Dependencies

    private let store: PersistenceStore

    // MARK: - Lifecycle

    init(store: PersistenceStore = PersistenceStore()) {
        self.store = store

        let saved = store.load([MembershipApplication].self, forKey: StorageKey.applications, fallback: [])
        self.applications = saved.isEmpty ? SeedData.starterApplications() : saved

        let savedRSVPs = store.load([UUID].self, forKey: StorageKey.rsvpEventIDs, fallback: [])
        self.rsvpEventIDs = Set(savedRSVPs)
    }

    // MARK: - Lookups

    func organization(id: String) -> Organization? {
        organizations.first { $0.id == id }
    }

    func event(id: UUID) -> OrgEvent? {
        events.first { $0.id == id }
    }

    func events(for organizationID: String) -> [OrgEvent] {
        events.filter { $0.organizationID == organizationID }
    }

    /// Text + category filtering used by the Explore screen.
    func organizations(matching query: String, category: OrgCategory?) -> [Organization] {
        organizations.filter { org in
            let matchesCategory = category == nil || org.category == category
            let trimmed = query.trimmed
            let matchesQuery = trimmed.isEmpty
                || org.name.localizedCaseInsensitiveContains(trimmed)
                || org.id.localizedCaseInsensitiveContains(trimmed)
            return matchesCategory && matchesQuery
        }
    }

    /// Status filtering used by the Events screen.
    func events(withStatus status: EventStatus?) -> [OrgEvent] {
        guard let status else { return events }
        return events.filter { $0.status == status }
    }

    var nextUpEvent: OrgEvent? {
        events.first { $0.status == .upcoming }
    }

    // MARK: - Organization creation

    /// Registers a brand new organization created from the Org Head sign-up form.
    @discardableResult
    func createOrganization(
        name: String,
        shortName: String,
        emoji: String,
        category: OrgCategory,
        colorHex: UInt32,
        headName: String
    ) -> Organization {
        let code = shortName.trimmed.isEmpty
            ? String(name.trimmed.prefix(3)).uppercased()
            : shortName.trimmed.uppercased()

        let organization = Organization(
            id: uniqueOrganizationID(startingFrom: code),
            name: name.trimmed,
            emoji: emoji,
            category: category,
            foundedYear: Calendar.current.component(.year, from: Date()),
            meetingSchedule: "Schedule to be announced",
            advisorName: "Advisor to be assigned",
            advisorEmail: "—",
            memberCount: 1,
            totalHeadcount: 1,
            isArchived: false,
            officers: [Officer(name: headName, position: "Org Head")],
            committees: [],
            colorHex: colorHex
        )
        organizations.append(organization)
        return organization
    }

    /// Removes an organization — used to roll back a half-finished sign-up.
    func removeOrganization(id: String) {
        organizations.removeAll { $0.id == id }
    }

    /// Appends a numeric suffix until the short code is free.
    private func uniqueOrganizationID(startingFrom code: String) -> String {
        guard organizations.contains(where: { $0.id == code }) else { return code }
        var counter = 2
        while organizations.contains(where: { $0.id == "\(code)\(counter)" }) {
            counter += 1
        }
        return "\(code)\(counter)"
    }

    // MARK: - Applications

    func applications(byApplicant id: UUID) -> [MembershipApplication] {
        applications
            .filter { $0.applicantID == id }
            .sorted { $0.submittedOn > $1.submittedOn }
    }

    func applications(forOrganization organizationID: String) -> [MembershipApplication] {
        applications
            .filter { $0.organizationID == organizationID }
            .sorted { $0.submittedOn > $1.submittedOn }
    }

    func application(by applicantID: UUID, organizationID: String) -> MembershipApplication? {
        applications.first { $0.applicantID == applicantID && $0.organizationID == organizationID }
    }

    func hasApplied(applicantID: UUID, organizationID: String) -> Bool {
        application(by: applicantID, organizationID: organizationID) != nil
    }

    @discardableResult
    func submitApplication(
        applicant: UserAccount,
        organizationID: String,
        message: String
    ) -> MembershipApplication {
        let application = MembershipApplication(
            applicantID: applicant.id,
            applicantName: applicant.fullName,
            organizationID: organizationID,
            message: message.trimmed.isEmpty ? "No message provided." : message.trimmed
        )
        applications.append(application)
        persistApplications()
        return application
    }

    func updateStatus(of applicationID: UUID, to status: ApplicationStatus) {
        guard let index = applications.firstIndex(where: { $0.id == applicationID }) else { return }
        applications[index].status = status
        persistApplications()
    }

    func withdrawApplication(id: UUID) {
        applications.removeAll { $0.id == id }
        persistApplications()
    }

    // MARK: - RSVPs

    func isRSVPd(_ eventID: UUID) -> Bool {
        rsvpEventIDs.contains(eventID)
    }

    func toggleRSVP(_ eventID: UUID) {
        if rsvpEventIDs.contains(eventID) {
            rsvpEventIDs.remove(eventID)
        } else {
            rsvpEventIDs.insert(eventID)
        }
        store.save(Array(rsvpEventIDs), forKey: StorageKey.rsvpEventIDs)
    }

    var rsvpdEvents: [OrgEvent] {
        events.filter { rsvpEventIDs.contains($0.id) }
    }

    // MARK: - Helpers

    private func persistApplications() {
        store.save(applications, forKey: StorageKey.applications)
    }
}
