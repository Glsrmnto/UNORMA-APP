//
//  AuthController.swift
//  UNORMA
//
//  CONTROLLER — owns registration, sign-in, sign-out and session persistence.
//  The signed-in account survives app relaunches.
//

import Foundation
import CryptoKit
import Observation

/// Every way sign-up or sign-in can fail, with copy ready for the UI.
enum AuthError: LocalizedError, Equatable {
    case emptyField(String)
    case invalidEmail
    case emailAlreadyRegistered
    case passwordTooShort
    case passwordMismatch
    case missingProgram
    case missingYearLevel
    case missingOrganization
    case accountNotFound
    case incorrectPassword

    var errorDescription: String? {
        switch self {
        case .emptyField(let name): return "\(name) is required."
        case .invalidEmail: return "Enter a valid email address."
        case .emailAlreadyRegistered: return "That email is already registered."
        case .passwordTooShort: return "Password must be at least 6 characters."
        case .passwordMismatch: return "Passwords do not match."
        case .missingProgram: return "Select your program."
        case .missingYearLevel: return "Select your year level."
        case .missingOrganization: return "Select the organization you manage."
        case .accountNotFound: return "No account found for that email."
        case .incorrectPassword: return "Incorrect password."
        }
    }
}

@Observable
final class AuthController {

    // MARK: - State

    private(set) var accounts: [UserAccount] = []
    private(set) var currentUser: UserAccount?

    var isSignedIn: Bool { currentUser != nil }

    // MARK: - Dependencies

    private let store: PersistenceStore

    // MARK: - Lifecycle

    init(store: PersistenceStore = PersistenceStore()) {
        self.store = store
        self.accounts = store.load([UserAccount].self, forKey: StorageKey.accounts, fallback: [])
        restoreSession()
    }

    /// Re-attaches the previously signed-in account, if the id is still valid.
    private func restoreSession() {
        let saved = store.load([String].self, forKey: StorageKey.currentUserID, fallback: [])
        guard let rawID = saved.first, let id = UUID(uuidString: rawID) else { return }
        currentUser = accounts.first { $0.id == id }
    }

    // MARK: - Registration

    @discardableResult
    func register(
        fullName: String,
        email: String,
        password: String,
        confirmPassword: String,
        role: UserRole,
        program: String?,
        yearLevel: YearLevel?,
        managedOrganizationID: String?
    ) throws -> UserAccount {

        let name = fullName.trimmed
        let mail = email.trimmed.lowercased()

        guard !name.isEmpty else { throw AuthError.emptyField("Full name") }
        guard !mail.isEmpty else { throw AuthError.emptyField("Email address") }
        guard mail.isValidEmail else { throw AuthError.invalidEmail }
        guard !accounts.contains(where: { $0.email == mail }) else {
            throw AuthError.emailAlreadyRegistered
        }
        guard password.count >= 6 else { throw AuthError.passwordTooShort }
        guard password == confirmPassword else { throw AuthError.passwordMismatch }

        switch role {
        case .student:
            guard let program, !program.isEmpty else { throw AuthError.missingProgram }
            guard yearLevel != nil else { throw AuthError.missingYearLevel }
        case .orgHead:
            guard let managedOrganizationID, !managedOrganizationID.isEmpty else {
                throw AuthError.missingOrganization
            }
        }

        let account = UserAccount(
            fullName: name,
            email: mail,
            passwordDigest: Self.digest(for: password),
            role: role,
            program: role == .student ? program : nil,
            yearLevel: role == .student ? yearLevel : nil,
            managedOrganizationID: role == .orgHead ? managedOrganizationID : nil
        )

        accounts.append(account)
        persistAccounts()
        return account
    }

    // MARK: - Sign in / out

    @discardableResult
    func signIn(email: String, password: String) throws -> UserAccount {
        let mail = email.trimmed.lowercased()

        guard !mail.isEmpty else { throw AuthError.emptyField("Email address") }
        guard !password.isEmpty else { throw AuthError.emptyField("Password") }
        guard let match = accounts.first(where: { $0.email == mail }) else {
            throw AuthError.accountNotFound
        }
        guard match.passwordDigest == Self.digest(for: password) else {
            throw AuthError.incorrectPassword
        }

        activate(match)
        return match
    }

    /// Marks an account as the live session and writes it to disk.
    func activate(_ account: UserAccount) {
        currentUser = account
        store.save([account.id.uuidString], forKey: StorageKey.currentUserID)
    }

    func signOut() {
        currentUser = nil
        store.remove(forKey: StorageKey.currentUserID)
    }

    // MARK: - Profile editing

    func updateCurrentUser(fullName: String, program: String?, yearLevel: YearLevel?) {
        guard var user = currentUser else { return }
        user.fullName = fullName.trimmed.isEmpty ? user.fullName : fullName.trimmed
        if user.role == .student {
            user.program = program
            user.yearLevel = yearLevel
        }
        if let index = accounts.firstIndex(where: { $0.id == user.id }) {
            accounts[index] = user
        }
        currentUser = user
        persistAccounts()
    }

    // MARK: - Helpers

    private func persistAccounts() {
        store.save(accounts, forKey: StorageKey.accounts)
    }

    /// SHA-256 over a fixed application salt. Keeps plaintext passwords off the device.
    private static func digest(for password: String) -> String {
        let salted = Data(("unorma.v1." + password).utf8)
        return SHA256.hash(data: salted)
            .map { String(format: "%02x", $0) }
            .joined()
    }
}

// MARK: - String conveniences

extension String {
    var trimmed: String {
        trimmingCharacters(in: .whitespacesAndNewlines)
    }

    var isValidEmail: Bool {
        let pattern = "^[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$"
        return range(of: pattern, options: .regularExpression) != nil
    }
}
