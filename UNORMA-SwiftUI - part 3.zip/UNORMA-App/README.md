# UNORMA — University Organization Manager

A functional SwiftUI prototype built from the UNORMA Figma design.
Design tokens are taken directly from the exported Figma Make project
(`src/index.css`), so colours, radii and borders match 1:1.

---

## Requirements

- **Xcode 16 or newer** — the project uses the synchronized-folder format
  (`PBXFileSystemSynchronizedRootGroup`), so new Swift files added to the
  `UNORMA/` folder are picked up automatically with no project edits.
- **iOS 17+** deployment target — state is managed with `@Observable` from
  the Observation framework. **Combine is not imported anywhere in this app.**

## Opening the project

1. Open `UNORMA.xcodeproj`.
2. Select the **UNORMA** target → **Signing & Capabilities** → choose your Team.
   (`DEVELOPMENT_TEAM` ships blank so the project opens cleanly on any machine.)
3. Choose an iPhone simulator and Run.

### If you are on Xcode 15 or older

Create a new iOS App project named `UNORMA` (SwiftUI interface), delete the
generated `ContentView.swift` and `UNORMAApp.swift`, then drag the four folders
(`Models`, `Controllers`, `DesignSystem`, `Views`) and `UNORMAApp.swift` from
this `UNORMA/` folder into the project with **"Create groups"** selected.
Set the deployment target to iOS 17.

---

## Architecture — MVC

| Layer | Folder | Responsibility |
|---|---|---|
| **Model** | `UNORMA/Models/` | Plain `Codable` value types. No UI, no state ownership. |
| **Controller** | `UNORMA/Controllers/` | `@Observable` classes owning state, validation and persistence. |
| **View** | `UNORMA/Views/` | `SwiftUI.View` structs only. They render and forward intent. |
| *(support)* | `UNORMA/DesignSystem/` | Reusable tokens and components shared by the views. |

Controllers are created once in `UNORMAApp.swift` and injected through the
environment, so no view ever constructs its own state store.

### File map

```
UNORMA/
├── UNORMAApp.swift                  App entry; creates & injects controllers
├── Models/
│   ├── UserAccount.swift            Account, UserRole, YearLevel
│   ├── Organization.swift           Organization, Officer, Committee, OrgCategory
│   ├── OrgEvent.swift               OrgEvent, AssignedRole, EventStatus
│   ├── MembershipApplication.swift  Application + ApplicationStatus
│   └── SeedData.swift               Starter catalogue (6 orgs, 9 events)
├── Controllers/
│   ├── AuthController.swift         Register / sign in / sign out / session
│   ├── DataController.swift         Orgs, events, applications, RSVPs
│   ├── ThemeController.swift        Light / midnight appearance
│   └── PersistenceStore.swift       Typed UserDefaults wrapper
├── DesignSystem/
│   ├── Palette.swift                Colour tokens (both palettes) + environment key
│   ├── Typography.swift             Fonts, radii, spacing
│   ├── BrandLogo.swift              Original mark, tile and wordmark
│   ├── CoreComponents.swift         Cards, headers, buttons, chips, tags, empty states
│   └── FormComponents.swift         Labelled fields, pickers, banners
└── Views/
    ├── RootView.swift               Splash → Auth → Tab shell
    ├── SplashView.swift             Animated launch screen
    ├── Auth/                        AuthView, SignInFormView, RegisterFormView
    ├── Shell/                       MainTabView, UNTabBar, TabDestination
    ├── Student/                     ExploreView, OrganizationDetailView, MyApplicationsView
    ├── OrgHead/                     MyOrgView, ReviewApplicationsView
    └── Shared/                      EventsView, EventDetailView, EventRow, ProfileView
```

---

## Screens & flow

1. **Splash** — logo tile springs in behind an expanding halo, wordmark rises,
   progress bar fills (~2.1s), then cross-fades to the next screen.
2. **Auth** — gradient brand header with an animated Sign In / Register pill
   toggle; forms slide in from opposite edges. Registering shows the
   "Welcome, …! Signing you in…" confirmation before opening the session.
3. **Tab shell** — a custom bottom bar (not `TabView`) with a sliding pill,
   a top-edge indicator, icon scale-up and a red badge for pending items.
   Each tab keeps its own `NavigationStack`, so back-stacks survive tab switches.

**Student tabs:** Explore · My Apps · Events · Profile
**Org Head tabs:** My Org · Applications · Events · Settings

Push destinations (organization detail, event detail) are registered once in
`MainTabView.routed()` and shared by every tab.

---

## What is fully implemented

- **Accounts (100%).** Registration validates name, email format, duplicate
  email, password length, confirmation match, and the role-specific fields.
  Passwords are stored as a salted SHA-256 digest via CryptoKit — never in
  plain text. The signed-in account is written to `UserDefaults` and restored
  automatically on next launch.
- Both roles register. Org Head can pick an existing organization or create a
  new one (name, abbreviation, category, colour swatch); the new organization
  is really created, and is rolled back if the account itself is rejected.
- Search, category filters, status filters.
- Apply to join (with message), withdraw, approve / reject — a decision made in
  the Org Head queue updates the student's tracker, because both read the same
  controller.
- RSVP toggle and the My Events scope.
- Dark mode toggle, profile editing, sign out with confirmation.
- All navigation between all screens.

## What is intentionally partial (~50%)

- Organization photo upload is a styled placeholder — no `PhotosPicker` wiring.
- Officer and committee management is display-only (no add / edit / remove).
- The university-wide admin role from the design file is not included; the app
  ships the Student and Org Head experiences.
- Notifications bell is decorative.

---

## Design system notes

Tokens are lifted from the Figma export:

| Token | Light | Midnight |
|---|---|---|
| Frame | `#F4F6FF` | `#080C3A` |
| Card | `#FFFFFF` | `#182190` |
| Input | `#F4F6FF` | `#0F1760` |
| Accent | `#5970E8` | `#5970E8` |
| Accent deep | `#0C1F6E` | `#8E9EF4` |
| Header gradient | `#0C1F6E → #1A3090` | `#090D3C → #0C1F6E` |

The design file uses DM Sans, which is not a system font on iOS. Rather than
bundle a font file, headings use `.system(design: .rounded)`, which carries the
same geometric feel. To match exactly, add `DMSans.ttf` to the target, list it
under `UIAppFonts`, and swap the font constructors in `Typography.swift` —
that one file is the only place fonts are declared.

No image assets are required. The logo is drawn with a `Shape` and circles, and
no asset catalog is referenced by the build settings.

## Fix log

**v1.1**

1. **Back navigation from detail screens.** `GradientHeader` composed its
   decorative orbs as layout children, so the 260pt stroked circle set the
   whole header's height. `clipShape` then ran against those inflated bounds
   and the outer `.frame(height:)` cropped the band from the centre, leaving
   the header's real content — including the back button — clipped out of
   view. The orbs now live in a `.background` layer, which is sized to the
   header but never contributes to its layout, so content drives the height.
   Call sites pass `minHeight:` instead of a hard `.frame(height:)`.
2. **Edge swipe-back.** Detail screens hide the system navigation bar, which
   also disables UIKit's interactive pop gesture. `edgeSwipeBack(perform:)`
   restores it as a `simultaneousGesture` filtered by start location, so it
   coexists with vertical scrolling instead of competing with it.
3. **Tab indicator alignment.** `ZStack(alignment: .top)` centres children
   horizontally, so the pill and the top bar were centred first and *then*
   offset — the error grew with distance from the middle tab. Switching to
   `.topLeading` makes each offset an absolute position, and both elements
   are now centred within their item by the same arithmetic the buttons use.

## Logo

An original mark: a cradling arc — the "U" of UNORMA, and the organization that
holds its members — with three rising dots above it for the members themselves.
Defined in `BrandLogo.swift` as `CradleArc`, `UnormaMark`, `UnormaLogoTile` and
`UnormaWordmark`.
